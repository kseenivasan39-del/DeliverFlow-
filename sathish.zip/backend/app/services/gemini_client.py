"""
gemini_client.py
DeliverFlow — Secure Gemini API client integration.
"""
import json
import logging
from typing import Any

from app.core.config import settings

log = logging.getLogger("deliverflow.gemini_client")

# Only configure Gemini if enabled
if settings.is_ai_enabled:
    import google.generativeai as genai
    genai.configure(api_key=settings.GEMINI_API_KEY)

def generate_json(prompt: str) -> dict[str, Any]:
    """
    Call Gemini and request JSON output.
    Retries once on invalid JSON.
    Never logs the prompt or API key.
    """
    if not settings.is_ai_enabled:
        raise RuntimeError("Gemini is not configured or AI_MODE is mock.")
    
    import google.generativeai as genai

    model = genai.GenerativeModel(
        model_name=settings.GEMINI_MODEL,
        generation_config={
            "temperature": 0.0,
            "response_mime_type": "application/json",
        }
    )

    retries = settings.GEMINI_MAX_RETRIES
    last_error = None

    for attempt in range(retries + 1):
        try:
            # We do NOT log the prompt here to avoid leaking sensitive data
            response = model.generate_content(prompt)
            text = response.text.strip()
            
            # Clean markdown fences if present
            if text.startswith("```"):
                lines = text.splitlines()
                if lines and lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].startswith("```"):
                    lines = lines[:-1]
                text = "\n".join(lines).strip()
                
            return json.loads(text)
        except json.JSONDecodeError as exc:
            last_error = exc
            if attempt == retries:
                log.error("Failed to parse Gemini JSON response after %d retries.", retries)
                raise ValueError("Invalid JSON response from Gemini") from exc
        except Exception as exc:
            last_error = exc
            if attempt == retries:
                log.error("Gemini API call failed after %d retries.", retries)
                raise RuntimeError("Gemini API failure") from exc

    raise RuntimeError(f"Unexpected failure in generate_json: {last_error}")
