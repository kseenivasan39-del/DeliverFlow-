"""
ai_extractor.py
DeliverFlow — AI extraction service.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from app.core.config import settings
from app.services import gemini_client

from ..schemas.enrichment import (
    AttributeName,
    AttributeStatus,
    ConflictSeverity,
    EnrichedAttribute,
    EnrichmentResult,
    EvidenceInput,
    ExtractionTier,
    PipelineWarning,
    ProductInput,
    RawAttributeExtraction,
    RawCandidateValue,
    RawExtractionOutput,
    ScoreFactors,
    ScoredCandidate,
    SourceInput,
)
from .fallback_store import get_fallback
from .trust_gate import (
    assign_attribute_status,
    compute_product_confidence,
    detect_conflict,
    infer_tier,
    score_candidate,
    authority_score,
)

log = logging.getLogger("deliverflow.ai_extractor")

# Path to prompt template
_PROMPT_PATH = (
    Path(__file__).resolve().parent.parent.parent.parent.parent
    / "shared" / "prompts" / "product_intelligence.v1.md"
)

# ─── PROMPT BUILDER ───────────────────────────────────────────────────────────

def _build_prompt(product: ProductInput, evidence: list[EvidenceInput]) -> str:
    product_json = json.dumps(product.model_dump(), indent=2)
    evidence_json = json.dumps(
        [e.model_dump() for e in evidence],
        indent=2,
        ensure_ascii=False,
    )

    if _PROMPT_PATH.exists():
        template = _PROMPT_PATH.read_text(encoding="utf-8")
        prompt = template.replace("{{product_json}}", product_json)
        prompt = prompt.replace("{{evidence_json}}", evidence_json)
        return prompt

    log.warning("Prompt template not found at %s — using inline fallback", _PROMPT_PATH)
    return f"""
You are a product data extraction engine for industrial valves.

Extract these six attributes from the evidence below.
Return ONLY a JSON object matching this schema — no markdown, no explanation.

Attributes: category, material, pressure, connection, temperature_range, description

Rules:
- Extract only values explicitly stated in the evidence text.
- If a value is not present or redacted, set value to null.
- Never hallucinate or infer beyond the text.
- Return one candidate per evidence record.

Product:
{product_json}

Evidence:
{evidence_json}

Return schema:
{{
  "product_id": "<string>",
  "mpn": "<string>",
  "extracted_at": "<ISO 8601>",
  "candidates": [
    {{
      "attribute_name": "<one of the 6 attributes>",
      "candidates": [
        {{
          "value": "<string or null>",
          "evidence_id": "<string>",
          "source_id": "<string>",
          "source_type": "<source_type>",
          "extraction_note": "<brief note or null>"
        }}
      ]
    }}
  ]
}}
""".strip()


# ─── TRUST GATE APPLICATION ──────────────────────────────────────────────────

def _apply_trust_gate(
    raw: RawExtractionOutput,
    sources: list[SourceInput],
) -> dict[AttributeName, EnrichedAttribute]:
    source_map = {s.source_id: s for s in sources}
    attributes: dict[AttributeName, EnrichedAttribute] = {}

    by_attr: dict[AttributeName, list[RawCandidateValue]] = {a: [] for a in AttributeName}
    for raw_attr in raw.candidates:
        for candidate in raw_attr.candidates:
            by_attr[raw_attr.attribute_name].append(candidate)

    for attr_name in AttributeName:
        all_candidates = by_attr[attr_name]
        non_null = [c for c in all_candidates if c.value]

        if not non_null:
            attributes[attr_name] = EnrichedAttribute(
                name=attr_name,
                value=None,
                status=AttributeStatus.MISSING,
                confidence=None,
                winning_source_id=None,
                conflict_summary=None,
                missing_reason="not_in_sources",
                missing_explanation=f"No non-null candidate found for '{attr_name}' across all evidence.",
                score_factors=None,
                candidates=[],
            )
            continue

        conflict = detect_conflict(attr_name, non_null)

        value_counts: dict[str, int] = {}
        for c in non_null:
            key = (c.value or "").strip().lower()
            value_counts[key] = value_counts.get(key, 0) + 1

        scored: list[ScoredCandidate] = []
        for c in non_null:
            tier = infer_tier(c.extraction_note)
            src = source_map.get(c.source_id)
            source_url = src.url if src else None
            key = (c.value or "").strip().lower()
            agree_count = max(0, value_counts.get(key, 1) - 1)

            conf, factors = score_candidate(
                attribute_name=attr_name,
                raw_candidate=c,
                extraction_tier=tier,
                mpn=raw.mpn,
                source_url=source_url,
                agreeing_source_count=agree_count,
                has_conflict=conflict.has_conflict,
            )

            src_type = c.source_type
            scored.append(ScoredCandidate(
                value=c.value or "",
                source_id=c.source_id,
                source_type=src_type,
                authority_score=authority_score(src_type),
                evidence_id=c.evidence_id,
                extraction_note=c.extraction_note,
                confidence=conf,
                score_factors=factors,
            ))

        winner = max(
            scored,
            key=lambda s: (s.confidence, s.authority_score),
        )

        status = assign_attribute_status(
            confidence=winner.confidence if not conflict.has_conflict else winner.confidence,
            has_conflict=conflict.has_conflict,
            all_candidates_null=(len(non_null) == 0),
        )

        attributes[attr_name] = EnrichedAttribute(
            name=attr_name,
            value=winner.value,
            status=status,
            confidence=winner.confidence,
            winning_source_id=winner.source_id,
            conflict_type=conflict.conflict_type,
            conflict_severity=conflict.severity,
            conflict_summary=conflict.conflict_summary,
            score_factors=winner.score_factors,
            candidates=scored,
        )

    return attributes


# ─── WARNINGS BUILDER ────────────────────────────────────────────────────────

def _build_warnings(
    attributes: dict[AttributeName, EnrichedAttribute],
    overall_confidence: int,
    pipeline_status: str,
) -> list[PipelineWarning]:
    warnings: list[PipelineWarning] = []

    for attr in attributes.values():
        if attr.status == AttributeStatus.CONFLICT:
            warnings.append(PipelineWarning(
                code="ATTRIBUTE_CONFLICT",
                attribute=attr.name.value,
                severity=attr.conflict_severity or ConflictSeverity.HIGH,
                message=attr.conflict_summary or f"Conflict detected on {attr.name}.",
                conflict_type=attr.conflict_type.value if attr.conflict_type else None,
                sources_in_conflict=[c.source_id for c in attr.candidates],
            ))

        if attr.status == AttributeStatus.MISSING:
            from .trust_gate import _HIGH_CRITICALITY
            severity = ConflictSeverity.HIGH if attr.name in _HIGH_CRITICALITY else ConflictSeverity.MEDIUM
            warnings.append(PipelineWarning(
                code="ATTRIBUTE_MISSING",
                attribute=attr.name.value,
                severity=severity,
                message=attr.missing_explanation or f"No evidence found for {attr.name}.",
                missing_reason=attr.missing_reason,
            ))

    if pipeline_status == "needs_review" and overall_confidence < 85:
        warnings.append(PipelineWarning(
            code="CONFIDENCE_CAP_APPLIED",
            attribute="product",
            severity=ConflictSeverity.MEDIUM,
            message=f"Overall confidence is {overall_confidence}. Product requires human review.",
        ))

    return warnings


# ─── MAIN PUBLIC FUNCTION ─────────────────────────────────────────────────────

def extract_product_intelligence(
    product: ProductInput,
    sources: list[SourceInput],
    evidence: list[EvidenceInput],
) -> EnrichmentResult:
    """
    Core extraction entry point. Called by the pipeline orchestrator.

    In mock mode:   returns a pre-built fixture for this MPN.
    In live mode:   calls Gemini, validates output, scores with trust_gate.
                    On failure: falls back to fixture gracefully.

    Always returns an EnrichmentResult — never raises.
    """

    # ── MOCK MODE ──────────────────────────────────────────────────────────
    if settings.is_mock_mode:
        log.info("[mock] Loading fixture for MPN '%s'", product.mpn)
        return get_fallback(product.mpn)

    # ── LIVE MODE ──────────────────────────────────────────────────────────
    if not evidence:
        log.warning("No evidence provided for MPN '%s' — skipping LLM call", product.mpn)
        return get_fallback(product.mpn)

    prompt = _build_prompt(product, evidence)
    
    try:
        log.info("Requesting JSON from Gemini for MPN '%s'", product.mpn)
        raw_data = gemini_client.generate_json(prompt)
        
        # Inject product_id / mpn if model omitted them
        raw_data.setdefault("product_id", product.product_id)
        raw_data.setdefault("mpn", product.mpn)
        raw_data.setdefault("extracted_at", datetime.now(timezone.utc).isoformat())

        raw_output = RawExtractionOutput.model_validate(raw_data)
        log.info("LLM extraction succeeded for MPN '%s'", product.mpn)
    except Exception as exc:
        log.error("AI extraction failed for MPN '%s': %s", product.mpn, exc)
        return get_fallback(product.mpn)

    # ── TRUST GATE ────────────────────────────────────────────────────────
    try:
        attributes = _apply_trust_gate(raw_output, sources)
        overall_confidence, pipeline_status = compute_product_confidence(attributes)
        warnings = _build_warnings(attributes, overall_confidence, pipeline_status)

        return EnrichmentResult(
            product_id=product.product_id,
            mpn=product.mpn,
            overall_confidence=overall_confidence,
            pipeline_status=pipeline_status,
            validation_status="passed",
            attributes=attributes,
            warnings=warnings,
            from_fallback=False,
        )

    except Exception as exc:
        log.error(
            "Trust gate failed for MPN '%s': %s",
            product.mpn, exc, exc_info=True,
        )
        return get_fallback(product.mpn)
