"""
trust_gate.py
DeliverFlow — confidence scoring and conflict detection.

Two entry points:

  score_candidate(candidate, source, extraction_tier) -> int
    Computes a 0–99 confidence score for a single extracted candidate value.
    Formula: model_confidence + source_authority_bonus + evidence_quality_bonus
             + agreement_bonus - conflict_penalty - ambiguity_penalty

  detect_conflict(attribute_name, candidates) -> ConflictDecision
    Determines whether a genuine conflict exists between candidates and
    classifies its type and severity.

Both functions are pure — no I/O, no state, no side effects.
Easy to unit test and easy to swap.
"""

from __future__ import annotations

import re
import logging
from dataclasses import dataclass, field
from typing import Optional

from ..schemas.enrichment import (
    AttributeName,
    AttributeStatus,
    ConflictSeverity,
    ConflictType,
    RawCandidateValue,
    ScoreFactors,
    ScoredCandidate,
    SourceType,
)

log = logging.getLogger("deliverflow.trust_gate")


# ─── SOURCE AUTHORITY WEIGHTS ────────────────────────────────────────────────
# Mirrors shared/rules/source_authority.yaml

_AUTHORITY_SCORE: dict[SourceType, float] = {
    SourceType.MANUFACTURER_DATASHEET: 1.00,
    SourceType.OFFICIAL_PRODUCT_PAGE:  0.90,
    SourceType.AUTHORIZED_DISTRIBUTOR: 0.80,
    SourceType.DISTRIBUTOR_PAGE:       0.60,
    SourceType.MARKETPLACE_LISTING:    0.40,
}


def authority_score(source_type: SourceType) -> float:
    return _AUTHORITY_SCORE.get(source_type, 0.40)


# ─── EXTRACTION CLARITY TIERS ─────────────────────────────────────────────────
# Mirrors shared/rules/confidence.yaml model_confidence tiers

class ExtractionTier:
    EXPLICIT_STRUCTURED_FIELD = "explicit_structured_field"   # score: 70
    EXPLICIT_PROSE             = "explicit_prose"              # score: 58
    INFERRED_FROM_MPN          = "inferred_from_mpn"           # score: 40
    INFERRED_FROM_CONTEXT      = "inferred_from_context"       # score: 25
    NOT_EXTRACTABLE            = "not_extractable"             # score:  0


_TIER_SCORES: dict[str, int] = {
    ExtractionTier.EXPLICIT_STRUCTURED_FIELD: 70,
    ExtractionTier.EXPLICIT_PROSE:             58,
    ExtractionTier.INFERRED_FROM_MPN:          40,
    ExtractionTier.INFERRED_FROM_CONTEXT:      25,
    ExtractionTier.NOT_EXTRACTABLE:             0,
}

_TIER_KEYWORDS: list[tuple[list[str], str]] = [
    (["table", "specification", "spec", "datasheet", "row", "field", "p-t table"], ExtractionTier.EXPLICIT_STRUCTURED_FIELD),
    (["bullet", "feature", "prose", "sentence", "description", "overview"],        ExtractionTier.EXPLICIT_PROSE),
    (["mpn", "suffix", "part number", "model number"],                              ExtractionTier.INFERRED_FROM_MPN),
    (["inferred", "implied", "context", "class", "family"],                         ExtractionTier.INFERRED_FROM_CONTEXT),
]


def infer_tier(extraction_note: Optional[str]) -> str:
    """Heuristically infer the extraction clarity tier from the model's extraction_note."""
    if not extraction_note:
        return ExtractionTier.EXPLICIT_PROSE
    note_lower = extraction_note.lower()
    for keywords, tier in _TIER_KEYWORDS:
        if any(kw in note_lower for kw in keywords):
            return tier
    return ExtractionTier.EXPLICIT_PROSE


# ─── EVIDENCE QUALITY SIGNALS ─────────────────────────────────────────────────

def _evidence_quality_bonus(
    attribute_name: AttributeName,
    value: Optional[str],
    extraction_note: Optional[str],
    mpn: Optional[str],
    source_url: Optional[str],
) -> int:
    """
    Compute evidence quality bonus. Capped at +15.
    Mirrors shared/rules/confidence.yaml evidence_quality_bonus.
    """
    bonus = 0
    note = (extraction_note or "").lower()
    val  = (value or "").lower()

    # Direct numeric specification (pressure, temperature)
    if attribute_name in (AttributeName.PRESSURE, AttributeName.TEMPERATURE_RANGE):
        if re.search(r"\d", val):
            bonus += 8

    # Exact MPN match in source URL or extraction note
    if mpn and source_url and mpn.lower() in source_url.lower():
        bonus += 5
    elif mpn and mpn.lower() in note:
        bonus += 3

    # Section title match
    if any(kw in note for kw in ["specification", "technical data", "rating", "p-t table"]):
        bonus += 2

    # Direct material with grade
    if attribute_name == AttributeName.MATERIAL:
        if re.search(r"\b3[01][46][lL]?\b|\bCF8M\b|\bWCB\b|\bA105\b", val or ""):
            bonus += 5

    # Series-level penalty
    if any(kw in note for kw in ["series", "family", "range", "product line"]):
        bonus -= 5

    # No unit penalty
    if attribute_name == AttributeName.PRESSURE and value and not re.search(r"bar|psi|mpa|kpa", val):
        bonus -= 3

    return max(-15, min(15, bonus))


# ─── CONFIDENCE SCORER ────────────────────────────────────────────────────────

def score_candidate(
    attribute_name: AttributeName,
    raw_candidate: RawCandidateValue,
    extraction_tier: str,
    mpn: Optional[str] = None,
    source_url: Optional[str] = None,
    agreeing_source_count: int = 0,
    has_conflict: bool = False,
) -> tuple[int, ScoreFactors]:
    """
    Compute a 0–99 confidence score for a single candidate value.

    Returns (confidence_score, ScoreFactors) so callers can surface
    the breakdown in the UI.
    """
    src_type    = raw_candidate.source_type
    model_conf  = _TIER_SCORES.get(extraction_tier, 58)
    auth_bonus  = round(authority_score(src_type) * 20)
    qual_bonus  = _evidence_quality_bonus(
        attribute_name,
        raw_candidate.value,
        raw_candidate.extraction_note,
        mpn,
        source_url,
    )
    agree_bonus = min(agreeing_source_count * 3, 6)
    conflict_pen = -25 if has_conflict else 0

    raw = model_conf + auth_bonus + qual_bonus + agree_bonus + conflict_pen
    clamped = max(0, min(99, raw))

    factors = ScoreFactors(
        model_confidence       = model_conf,
        source_authority_bonus = auth_bonus,
        evidence_quality_bonus = qual_bonus,
        agreement_bonus        = agree_bonus,
        conflict_penalty       = conflict_pen,
        ambiguity_penalty      = 0,
        raw                    = raw,
        clamped                = clamped,
    )
    return clamped, factors


# ─── CONFLICT DETECTION ───────────────────────────────────────────────────────

@dataclass
class ConflictDecision:
    has_conflict:     bool = False
    conflict_type:    Optional[ConflictType] = None
    severity:         Optional[ConflictSeverity] = None
    conflict_summary: Optional[str] = None
    flagged_sources:  list[str] = field(default_factory=list)


def _parse_bar(value: str) -> Optional[float]:
    """Extract a float bar value from a string like '16 bar' or '1000 PSI'."""
    value = value.lower().strip()
    m = re.search(r"([\d.]+)\s*(bar|psi|mpa|kpa)", value)
    if not m:
        return None
    num, unit = float(m.group(1)), m.group(2)
    conversions = {"bar": 1.0, "psi": 1 / 14.5038, "mpa": 10.0, "kpa": 0.01}
    return round(num * conversions[unit], 3)


def _parse_temp_range(value: str) -> Optional[tuple[float, float]]:
    """Extract (min_celsius, max_celsius) from '-20°C to +200°C'."""
    nums = re.findall(r"[+-]?\s*\d+(?:\.\d+)?", value)
    if len(nums) < 2:
        return None
    try:
        return float(nums[0].replace(" ", "")), float(nums[1].replace(" ", ""))
    except ValueError:
        return None


def detect_conflict(
    attribute_name: AttributeName,
    candidates: list[RawCandidateValue],
) -> ConflictDecision:
    """
    Determine whether a genuine conflict exists between non-null candidates.

    Rules per attribute:
      pressure          → >5% numeric difference after unit normalization
      temperature_range → >5°C difference in min or max
      material          → same family, different grade → grade_mismatch
      connection        → different type or size → genuine_conflict
      category          → different normalized type → genuine_conflict
      description       → no conflict detection (synthesized field)

    Returns a ConflictDecision — never raises.
    """
    non_null = [c for c in candidates if c.value]
    if len(non_null) < 2:
        return ConflictDecision(has_conflict=False)

    # ── PRESSURE ──
    if attribute_name == AttributeName.PRESSURE:
        bars = [(c, _parse_bar(c.value)) for c in non_null]
        bars = [(c, b) for c, b in bars if b is not None]
        if len(bars) < 2:
            return ConflictDecision(has_conflict=False)

        max_bar = max(b for _, b in bars)
        min_bar = min(b for _, b in bars)

        if max_bar == 0:
            return ConflictDecision(has_conflict=False)

        diff_pct = abs(max_bar - min_bar) / max_bar

        if diff_pct <= 0.05:
            # Minor variance — not a conflict
            return ConflictDecision(has_conflict=False)

        # Classify: Class 150 (~10 bar) vs PN16 (16 bar) is the canonical demo case
        values_set = {round(b) for _, b in bars}
        is_class_mismatch = 10 in values_set and 16 in values_set

        return ConflictDecision(
            has_conflict=True,
            conflict_type=ConflictType.DATA_ENTRY_ERROR if is_class_mismatch else ConflictType.GENUINE_CONFLICT,
            severity=ConflictSeverity.HIGH,
            conflict_summary=(
                f"Sources disagree on pressure: "
                + ", ".join(f"'{c.value}' ({c.source_type})" for c, _ in bars)
                + (". Values correspond to different pressure classes (ASME Class 150 vs PN16)."
                   if is_class_mismatch else ".")
            ),
            flagged_sources=[c.source_id for c, _ in bars],
        )

    # ── TEMPERATURE RANGE ──
    if attribute_name == AttributeName.TEMPERATURE_RANGE:
        parsed = [(c, _parse_temp_range(c.value)) for c in non_null]
        parsed = [(c, t) for c, t in parsed if t is not None]
        if len(parsed) < 2:
            return ConflictDecision(has_conflict=False)

        mins = [t[0] for _, t in parsed]
        maxs = [t[1] for _, t in parsed]

        if abs(max(mins) - min(mins)) > 5 or abs(max(maxs) - min(maxs)) > 5:
            return ConflictDecision(
                has_conflict=True,
                conflict_type=ConflictType.GENUINE_CONFLICT,
                severity=ConflictSeverity.MEDIUM,
                conflict_summary=(
                    "Sources report different temperature ranges: "
                    + ", ".join(f"'{c.value}' ({c.source_type})" for c, _ in parsed)
                ),
                flagged_sources=[c.source_id for c, _ in parsed],
            )
        return ConflictDecision(has_conflict=False)

    # ── MATERIAL ──
    if attribute_name == AttributeName.MATERIAL:
        # Normalize: extract numeric grade if present
        def extract_grade(v: str) -> Optional[str]:
            m = re.search(r"\b(3[01][46][lL]?|WCB|A105|A216|CF8M|CF8|GG25|GGG40)\b", v)
            return m.group(1).upper() if m else None

        grades = [(c, extract_grade(c.value)) for c in non_null]
        known_grades = [(c, g) for c, g in grades if g is not None]

        if len(known_grades) >= 2:
            unique_grades = {g for _, g in known_grades}
            if len(unique_grades) > 1:
                # Multiple distinct grades — genuine conflict
                return ConflictDecision(
                    has_conflict=True,
                    conflict_type=ConflictType.GRADE_MISMATCH,
                    severity=ConflictSeverity.HIGH,
                    conflict_summary=(
                        "Sources report different material grades: "
                        + ", ".join(f"'{c.value}' ({c.source_type})" for c in non_null)
                    ),
                    flagged_sources=[c.source_id for c in non_null],
                )
        # One grade-specific vs one vague — not a conflict, prefer specific
        return ConflictDecision(has_conflict=False)

    # ── CONNECTION ──
    if attribute_name == AttributeName.CONNECTION:
        def connection_key(v: str) -> str:
            """Normalize to 'TYPE:SIZE' for comparison."""
            v = v.upper()
            conn_type = "NPT" if "NPT" in v else "BSP" if "BSP" in v else \
                        "FLANGED" if "FLANG" in v else "SW" if "SOCKET" in v else "OTHER"
            size = re.search(r"(\d+/\d+|\d+)\s*(?:IN|INCH|\")?", v)
            return f"{conn_type}:{size.group(1) if size else 'UNK'}"

        keys = {connection_key(c.value) for c in non_null}
        if len(keys) > 1:
            return ConflictDecision(
                has_conflict=True,
                conflict_type=ConflictType.GENUINE_CONFLICT,
                severity=ConflictSeverity.HIGH,
                conflict_summary=(
                    "Sources report different connection types or sizes: "
                    + ", ".join(f"'{c.value}' ({c.source_type})" for c in non_null)
                ),
                flagged_sources=[c.source_id for c in non_null],
            )
        return ConflictDecision(has_conflict=False)

    # ── CATEGORY ──
    if attribute_name == AttributeName.CATEGORY:
        normalized = {c.value.lower().strip() for c in non_null}
        if len(normalized) > 1:
            return ConflictDecision(
                has_conflict=True,
                conflict_type=ConflictType.GENUINE_CONFLICT,
                severity=ConflictSeverity.MEDIUM,
                conflict_summary=(
                    "Sources report different product categories: "
                    + ", ".join(f"'{c.value}'" for c in non_null)
                ),
                flagged_sources=[c.source_id for c in non_null],
            )
        return ConflictDecision(has_conflict=False)

    # DESCRIPTION: no conflict detection
    return ConflictDecision(has_conflict=False)


# ─── STATUS ASSIGNMENT ────────────────────────────────────────────────────────

_CONFIDENCE_THRESHOLD = 85    # verified
_REVIEW_THRESHOLD     = 60    # needs_review below this


def assign_attribute_status(
    confidence: Optional[int],
    has_conflict: bool,
    all_candidates_null: bool,
) -> AttributeStatus:
    """
    Convert a confidence score and conflict/missing flags into an AttributeStatus.
    Conflict and missing are rule overrides — they ignore the numeric score.
    """
    if all_candidates_null:
        return AttributeStatus.MISSING
    if has_conflict:
        return AttributeStatus.CONFLICT
    if confidence is None:
        return AttributeStatus.UNKNOWN
    if confidence >= _CONFIDENCE_THRESHOLD:
        return AttributeStatus.VERIFIED
    if confidence >= _REVIEW_THRESHOLD:
        return AttributeStatus.NEEDS_REVIEW
    return AttributeStatus.LOW_CONFIDENCE


# ─── PRODUCT-LEVEL CONFIDENCE ─────────────────────────────────────────────────

_ATTRIBUTE_WEIGHTS: dict[AttributeName, float] = {
    AttributeName.PRESSURE:          0.25,
    AttributeName.MATERIAL:          0.20,
    AttributeName.TEMPERATURE_RANGE: 0.20,
    AttributeName.CONNECTION:        0.15,
    AttributeName.CATEGORY:          0.10,
    AttributeName.DESCRIPTION:       0.10,
}

_HIGH_CRITICALITY = {
    AttributeName.PRESSURE,
    AttributeName.MATERIAL,
    AttributeName.TEMPERATURE_RANGE,
}


def compute_product_confidence(
    attributes: dict[AttributeName, "EnrichedAttribute"],  # noqa: F821
) -> tuple[int, str]:
    """
    Compute overall product confidence and determine pipeline_status.

    Returns (overall_confidence, pipeline_status).
    pipeline_status is one of: "ready" | "needs_review" | "failed"
    """
    from ..schemas.enrichment import EnrichedAttribute  # local import to avoid circular

    weighted_sum = 0.0

    for attr_name, weight in _ATTRIBUTE_WEIGHTS.items():
        attr = attributes.get(attr_name)
        conf = (attr.confidence or 0) if attr else 0
        weighted_sum += conf * weight

    overall = max(0, min(99, round(weighted_sum)))

    # Check caps
    has_high_crit_conflict = any(
        attributes.get(a) and attributes[a].status == AttributeStatus.CONFLICT
        for a in _HIGH_CRITICALITY
    )
    has_high_crit_missing = any(
        attributes.get(a) and attributes[a].status == AttributeStatus.MISSING
        for a in _HIGH_CRITICALITY
    )

    if has_high_crit_conflict:
        overall = min(overall, 70)
        return overall, "needs_review"

    if has_high_crit_missing:
        overall = min(overall, 65)
        return overall, "needs_review"

    needs_review_attrs = [
        a for a in attributes.values()
        if a.status in (
            AttributeStatus.CONFLICT,
            AttributeStatus.LOW_CONFIDENCE,
            AttributeStatus.MISSING,
            AttributeStatus.NEEDS_REVIEW,
        )
    ]

    if needs_review_attrs or overall < _CONFIDENCE_THRESHOLD:
        return overall, "needs_review"

    return overall, "ready"
