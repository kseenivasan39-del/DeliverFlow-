"""
fallback_store.py
DeliverFlow — fixture loader for mock mode and AI failure fallback.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from functools import lru_cache
from typing import Optional

from ..schemas.enrichment import (
    EnrichmentResult,
    EnrichedAttribute,
    AttributeName,
    AttributeStatus,
    PipelineWarning,
    ConflictSeverity,
)

log = logging.getLogger("deliverflow.fallback_store")

# ─── PATH RESOLUTION ──────────────────────────────────────────────────────────

_SERVICES_DIR    = Path(__file__).resolve().parent
_BACKEND_DIR     = _SERVICES_DIR.parent.parent
_REPO_ROOT       = _BACKEND_DIR.parent
_FALLBACK_DIR    = _REPO_ROOT / "shared" / "demo-data" / "fallback"


# ─── INTERNAL HELPERS ─────────────────────────────────────────────────────────

@lru_cache(maxsize=16)
def _load_fixture_raw(mpn: str) -> Optional[dict]:
    path = _FALLBACK_DIR / f"{mpn}.json"
    if not path.exists():
        log.debug("No fallback fixture found for MPN '%s' at %s", mpn, path)
        return None

    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        log.info("Loaded fallback fixture: %s", path.name)
        return raw
    except (json.JSONDecodeError, OSError) as exc:
        log.error("Failed to read fixture for MPN '%s': %s", mpn, exc)
        return None

def _raw_to_enrichment_result(raw: dict, mpn: str) -> EnrichmentResult:
    raw_attrs: dict = raw.get("attributes", {})
    attributes: dict[AttributeName, EnrichedAttribute] = {}

    for attr_name_str, attr_data in raw_attrs.items():
        try:
            attr_name = AttributeName(attr_name_str)
        except ValueError:
            continue

        raw_candidates = attr_data.get("candidates", [])
        candidates = []
        for c in raw_candidates:
            sf = attr_data.get("score_factors")
            if sf:
                from ..schemas.enrichment import ScoreFactors, ScoredCandidate
                try:
                    score_factors = ScoreFactors(
                        model_confidence=sf.get("model_confidence", 0),
                        source_authority_bonus=sf.get("source_authority_bonus", 0),
                        evidence_quality_bonus=sf.get("evidence_quality_bonus", 0),
                        agreement_bonus=sf.get("agreement_bonus", 0),
                        conflict_penalty=sf.get("conflict_penalty", 0),
                        ambiguity_penalty=sf.get("ambiguity_penalty", 0),
                        raw=sf.get("raw", sf.get("clamped", 0)),
                        clamped=sf.get("clamped", 0),
                    )
                    candidate = ScoredCandidate(
                        value=c.get("value", ""),
                        normalized_from=c.get("normalized_from"),
                        normalized_bar=c.get("normalized_bar"),
                        min_celsius=c.get("min_celsius"),
                        max_celsius=c.get("max_celsius"),
                        source_id=c.get("source_id", ""),
                        source_type=c.get("source_type", "distributor_page"),
                        authority_score=c.get("authority_score", 0.5),
                        evidence_id=c.get("evidence_id", ""),
                        extraction_note=c.get("extraction_note"),
                        confidence=sf.get("clamped", 0),
                        score_factors=score_factors,
                    )
                    candidates.append(candidate)
                except Exception:
                    pass

        status_str = attr_data.get("status", "unknown")
        try:
            status = AttributeStatus(status_str)
        except ValueError:
            status = AttributeStatus.UNKNOWN

        conflict_summary = attr_data.get("conflict_summary")
        if status == AttributeStatus.CONFLICT and not conflict_summary:
            conflict_summary = "Conflict detected — see candidate values for details."

        attributes[attr_name] = EnrichedAttribute(
            name=attr_name,
            value=attr_data.get("value"),
            status=status,
            confidence=attr_data.get("confidence"),
            winning_source_id=attr_data.get("winning_source_id"),
            conflict_type=attr_data.get("conflict_type"),
            conflict_severity=attr_data.get("conflict_severity"),
            conflict_summary=conflict_summary,
            missing_reason=attr_data.get("missing_reason"),
            missing_explanation=attr_data.get("missing_explanation"),
            candidates=candidates,
            normalized_bar=attr_data.get("normalized_bar"),
            min_celsius=attr_data.get("min_celsius"),
            max_celsius=attr_data.get("max_celsius"),
        )

    warnings = []
    for w in raw.get("warnings", []):
        try:
            severity = ConflictSeverity(w.get("severity", "low"))
        except ValueError:
            severity = ConflictSeverity.LOW
        warnings.append(PipelineWarning(
            code=w.get("code", "UNKNOWN"),
            attribute=w.get("attribute"),
            severity=severity,
            message=w.get("message", ""),
            conflict_type=w.get("conflict_type"),
            sources_in_conflict=w.get("sources_in_conflict", []),
            missing_reason=w.get("missing_reason"),
        ))

    return EnrichmentResult(
        product_id=raw.get("product_id", f"prod-{mpn.lower()}"),
        mpn=raw.get("mpn", mpn),
        overall_confidence=raw.get("overall_confidence"),
        pipeline_status=raw.get("status", "needs_review"),
        validation_status=raw.get("validation_status", "fixture"),
        attributes=attributes,
        warnings=warnings,
        from_fallback=True,
    )

def _generic_fallback(mpn: str) -> EnrichmentResult:
    """Return a generic safe response when no fixture exists."""
    empty_attrs = {
        attr: EnrichedAttribute(
            name=attr,
            value=None,
            status=AttributeStatus.MISSING,
            confidence=20,
            winning_source_id=None,
            conflict_summary=None,
            missing_reason="no_data",
            missing_explanation="Generic fallback used due to missing fixture.",
            score_factors=None,
            candidates=[],
        )
        for attr in AttributeName
    }
    return EnrichmentResult(
        product_id=f"prod-{mpn.lower()}",
        mpn=mpn,
        overall_confidence=20,
        pipeline_status="needs_review",
        validation_status="fallback",
        attributes=empty_attrs,
        warnings=[PipelineWarning(
            code="GENERIC_FALLBACK",
            attribute="product",
            severity=ConflictSeverity.MEDIUM,
            message="No specific fallback fixture found. Generic safe data used.",
        )],
        from_fallback=True,
    )

# ─── PUBLIC API ───────────────────────────────────────────────────────────────

def get_fallback(mpn: str) -> EnrichmentResult:
    """
    Return a fixture-based EnrichmentResult for the given MPN.
    If no fixture exists, return a generic safe response.
    """
    raw = _load_fixture_raw(mpn)
    if raw is None:
        log.warning("No fixture found for MPN '%s', returning generic safe fallback.", mpn)
        return _generic_fallback(mpn)

    try:
        return _raw_to_enrichment_result(raw, mpn)
    except Exception as exc:
        log.error(
            "Fixture for MPN '%s' failed to parse into EnrichmentResult: %s",
            mpn, exc, exc_info=True,
        )
        return _generic_fallback(mpn)


def list_fixture_mpns() -> list[str]:
    if not _FALLBACK_DIR.exists():
        return []
    return [p.stem for p in _FALLBACK_DIR.glob("*.json")]

def has_fixture(mpn: str) -> bool:
    return (_FALLBACK_DIR / f"{mpn}.json").exists()
