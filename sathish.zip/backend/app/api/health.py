"""
health.py
DeliverFlow — Health check endpoint.
"""
from fastapi import APIRouter
from app.core.config import settings
from app.services.fallback_store import has_fixture

router = APIRouter()

@router.get("/health")
def health_check():
    return {
        "status": "ok",
        "ai_mode": settings.AI_MODE,
        "ai_configured": settings.is_ai_enabled,
        "fallback_available": has_fixture("VAL-316-100")
    }
