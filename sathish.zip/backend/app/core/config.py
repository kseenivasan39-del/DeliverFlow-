"""
config.py
DeliverFlow - Configuration management
"""
from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    GEMINI_API_KEY: Optional[str] = None
    AI_MODE: str = "mock"
    GEMINI_MODEL: str = "gemini-pro"
    GEMINI_TIMEOUT_SECONDS: int = 30
    GEMINI_MAX_RETRIES: int = 1

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @property
    def is_ai_enabled(self) -> bool:
        """True if AI_MODE is 'live' and GEMINI_API_KEY is provided."""
        return self.AI_MODE.lower() == "live" and bool(self.GEMINI_API_KEY)

    @property
    def is_mock_mode(self) -> bool:
        """True if AI_MODE is 'mock' or API key is missing."""
        return not self.is_ai_enabled

settings = Settings()
