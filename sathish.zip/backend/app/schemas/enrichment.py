"""
enrichment.py
DeliverFlow — Pydantic schemas for the AI extraction pipeline.

These are internal service schemas, not the public API response models.
They represent what the AI extractor produces and what the trust gate
validates before the pipeline assembles the final product record.
"""

from __future__ import annotations

from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, model_validator


# ─── ENUMS ────────────────────────────────────────────────────────────────────

class AttributeName(str, Enum):
    CATEGORY          = "category"
    MATERIAL          = "material"
    PRESSURE          = "pressure"
    CONNECTION        = "connection"
    TEMPERATURE_RANGE = "temperature_range"
    DESCRIPTION       = "description"


class SourceType(str, Enum):
    MANUFACTURER_DATASHEET = "manufacturer_datasheet"
    OFFICIAL_PRODUCT_PAGE  = "official_product_page"
    AUTHORIZED_DISTRIBUTOR = "authorized_distributor"
    DISTRIBUTOR_PAGE       = "distributor_page"
    MARKETPLACE_LISTING    = "marketplace_listing"


class AttributeStatus(str, Enum):
    VERIFIED       = "verified"
    LOW_CONFIDENCE = "low_confidence"
    CONFLICT       = "conflict"
    MISSING        = "missing"
    NEEDS_REVIEW   = "needs_review"
    ACCEPTED       = "accepted"
    EDITED         = "edited"
    REJECTED       = "rejected"
    UNKNOWN        = "unknown"


class ConflictType(str, Enum):
    UNIT_MISMATCH   = "unit_mismatch"
    GRADE_MISMATCH  = "grade_mismatch"
    ROUNDING        = "rounding"
    DATA_ENTRY_ERROR = "data_entry_error"
    GENUINE_CONFLICT = "genuine_conflict"


class ConflictSeverity(str, Enum):
    LOW    = "low"
    MEDIUM = "medium"
    HIGH   = "high"


# ─── INPUT SCHEMAS ────────────────────────────────────────────────────────────

class SourceInput(BaseModel):
    """A discovered source, passed into the extractor."""
    source_id:       str
    source_type:     SourceType
    url:             str
    authority_score: float = Field(ge=0.0, le=1.0)
    trust_label:     str


class EvidenceInput(BaseModel):
    """A retrieved evidence record, passed into the extractor."""
    evidence_id: str
    source_id:   str
    source_type: SourceType
    raw_text:    str
    retrieved_at: str


class ProductInput(BaseModel):
    """Minimal product stub provided by the caller."""
    product_id: str
    mpn:        str
    brand:      str
    description: str


# ─── AI RAW OUTPUT ────────────────────────────────────────────────────────────

class RawCandidateValue(BaseModel):
    """
    A single attribute candidate as returned directly by the LLM.
    May not yet be validated or scored.
    """
    value:           Optional[str] = None
    evidence_id:     str
    source_id:       str
    source_type:     SourceType
    extraction_note: Optional[str] = None


class RawAttributeExtraction(BaseModel):
    """Raw extraction result for one attribute, from one evidence record."""
    attribute_name:  AttributeName
    candidates:      list[RawCandidateValue]


class RawExtractionOutput(BaseModel):
    """
    The full structured output expected from the AI extraction call.
    Validated by the extractor before any downstream processing.
    """
    product_id:   str
    mpn:          str
    extracted_at: str
    candidates:   list[RawAttributeExtraction]


# ─── SCORE FACTORS ────────────────────────────────────────────────────────────

class ScoreFactors(BaseModel):
    """Breakdown of how a confidence score was computed."""
    model_confidence:       int = Field(ge=0, le=70)
    source_authority_bonus: int = Field(ge=0, le=20)
    evidence_quality_bonus: int = Field(ge=-15, le=15)
    agreement_bonus:        int = Field(ge=0, le=6)
    conflict_penalty:       int = Field(le=0, default=0)
    ambiguity_penalty:      int = Field(le=0, default=0)
    raw:                    int
    clamped:                int = Field(ge=0, le=99)


# ─── SCORED CANDIDATE ─────────────────────────────────────────────────────────

class ScoredCandidate(BaseModel):
    """A validated, scored candidate value for one attribute."""
    value:           str
    normalized_from: Optional[str] = None
    normalized_bar:  Optional[float] = None
    min_celsius:     Optional[float] = None
    max_celsius:     Optional[float] = None
    source_id:       str
    source_type:     SourceType
    authority_score: float
    evidence_id:     str
    extraction_note: Optional[str] = None
    confidence:      int = Field(ge=0, le=99)
    score_factors:   ScoreFactors


# ─── ENRICHED ATTRIBUTE ───────────────────────────────────────────────────────

class EnrichedAttribute(BaseModel):
    """
    Final attribute record assembled after scoring, conflict detection,
    and status assignment. Ready for the product record.
    """
    name:                      AttributeName
    value:                     Optional[str] = None
    status:                    AttributeStatus
    confidence:                Optional[int] = Field(default=None, ge=0, le=99)
    winning_source_id:         Optional[str] = None
    conflict_type:             Optional[ConflictType] = None
    conflict_severity:         Optional[ConflictSeverity] = None
    conflict_summary:          Optional[str] = None
    missing_reason:            Optional[str] = None
    missing_explanation:       Optional[str] = None
    score_factors:             Optional[ScoreFactors] = None
    candidates:                list[ScoredCandidate] = Field(default_factory=list)
    normalized_bar:            Optional[float] = None
    min_celsius:               Optional[float] = None
    max_celsius:               Optional[float] = None

    @model_validator(mode="after")
    def conflict_requires_summary(self) -> "EnrichedAttribute":
        if self.status == AttributeStatus.CONFLICT and not self.conflict_summary:
            raise ValueError("conflict_summary is required when status is 'conflict'")
        return self


# ─── PIPELINE WARNING ─────────────────────────────────────────────────────────

class PipelineWarning(BaseModel):
    code:                str
    attribute:           Optional[str] = None
    severity:            ConflictSeverity
    message:             str
    conflict_type:       Optional[str] = None
    sources_in_conflict: list[str] = Field(default_factory=list)
    missing_reason:      Optional[str] = None


# ─── ENRICHMENT RESULT ────────────────────────────────────────────────────────

class EnrichmentResult(BaseModel):
    """
    The final output of extract_product_intelligence().
    Consumed by the pipeline orchestrator to update the product record.
    """
    product_id:         str
    mpn:                str
    overall_confidence: Optional[int] = Field(default=None, ge=0, le=99)
    pipeline_status:    str            # "ready" | "needs_review" | "failed"
    validation_status:  str
    attributes:         dict[AttributeName, EnrichedAttribute]
    warnings:           list[PipelineWarning] = Field(default_factory=list)
    from_fallback:      bool = False   # True when mock/fixture data was used

    @property
    def needs_review(self) -> bool:
        return self.pipeline_status == "needs_review"

    @property
    def is_ready(self) -> bool:
        return self.pipeline_status == "ready"

    def attributes_by_status(self, status: AttributeStatus) -> list[EnrichedAttribute]:
        return [a for a in self.attributes.values() if a.status == status]
