"""
test_enrichment.py
DeliverFlow — backend test suite.

Run with:
    cd backend
    pytest tests/test_enrichment.py -v

Requirements:
    pip install pytest pytest-asyncio

Coverage:
    GT-001  clean verified product
    GT-002  conflict product (pressure)
    GT-003  missing evidence product (no hallucination)
    GT-004  confidence floor for single low-authority source
    GT-005  conflict detected for >5% pressure difference
    GT-006  minor variance (≤5%) is NOT a conflict
    GT-007  null candidates → missing (not low_confidence)
    GT-008  mock mode never calls LLM
    GT-009  live mode falls back after two LLM failures
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# ─── PATH SETUP ──────────────────────────────────────────────────────────────
# Allow imports from backend/app without installing the package
_BACKEND = Path(__file__).resolve().parent.parent
if str(_BACKEND) not in sys.path:
    sys.path.insert(0, str(_BACKEND))

from app.schemas.enrichment import (
    AttributeName,
    AttributeStatus,
    EvidenceInput,
    ExtractionTier,
    ProductInput,
    RawCandidateValue,
    SourceInput,
    SourceType,
)
from app.services.fallback_store import get_fallback, has_fixture
from app.services.trust_gate import (
    assign_attribute_status,
    compute_product_confidence,
    detect_conflict,
    score_candidate,
)

# ─── FIXTURES ────────────────────────────────────────────────────────────────

@pytest.fixture
def product_verified() -> ProductInput:
    return ProductInput(
        product_id="prod-val-316-100",
        mpn="VAL-316-100",
        brand="Acme Industrial",
        description="Full-bore 316SS ball valve, DN25, PN16",
    )


@pytest.fixture
def product_conflict() -> ProductInput:
    return ProductInput(
        product_id="prod-val-316-100-c",
        mpn="VAL-316-100-C",
        brand="Acme Industrial",
        description="2-piece 316SS ball valve, DN25, Class 150 flanged",
    )


@pytest.fixture
def product_missing() -> ProductInput:
    return ProductInput(
        product_id="prod-val-316-100-m",
        mpn="VAL-316-100-M",
        brand="Acme Industrial",
        description="Miniature 316SS ball valve, 1/4 NPT",
    )


@pytest.fixture
def source_datasheet() -> SourceInput:
    return SourceInput(
        source_id="src-acme-ds-100",
        source_type=SourceType.MANUFACTURER_DATASHEET,
        url="https://acmeindustrial.com/datasheets/VAL-316-100-RevC.pdf",
        authority_score=1.0,
        trust_label="very_high",
    )


@pytest.fixture
def source_distributor() -> SourceInput:
    return SourceInput(
        source_id="src-proline-dist-100c",
        source_type=SourceType.DISTRIBUTOR_PAGE,
        url="https://prolineindustrial.net/products/val-316-100-c",
        authority_score=0.58,
        trust_label="medium",
    )


def make_candidate(
    value: str | None,
    source_id: str = "src-001",
    source_type: SourceType = SourceType.MANUFACTURER_DATASHEET,
    extraction_note: str | None = "Specifications table",
    evidence_id: str = "ev-001",
) -> RawCandidateValue:
    return RawCandidateValue(
        value=value,
        evidence_id=evidence_id,
        source_id=source_id,
        source_type=source_type,
        extraction_note=extraction_note,
    )


# ─── GT-001: CLEAN VERIFIED PRODUCT ─────────────────────────────────────────

class TestCleanVerifiedProduct:
    """GT-001 — VAL-316-100 fixture returns all attributes verified."""

    def test_fixture_exists(self):
        assert has_fixture("VAL-316-100"), "Fixture file must exist for VAL-316-100"

    def test_pipeline_status_is_ready(self):
        result = get_fallback("VAL-316-100")
        assert result is not None
        assert result.pipeline_status == "ready", (
            f"Expected pipeline_status='ready', got '{result.pipeline_status}'"
        )

    def test_overall_confidence_above_90(self):
        result = get_fallback("VAL-316-100")
        assert result.overall_confidence is not None
        assert result.overall_confidence >= 90, (
            f"Expected confidence ≥ 90, got {result.overall_confidence}"
        )

    def test_all_six_attributes_present(self):
        result = get_fallback("VAL-316-100")
        for attr in AttributeName:
            assert attr in result.attributes, f"Attribute '{attr}' missing from result"

    def test_no_warnings(self):
        result = get_fallback("VAL-316-100")
        assert len(result.warnings) == 0, (
            f"Expected 0 warnings, got {len(result.warnings)}: "
            + ", ".join(w.code for w in result.warnings)
        )

    def test_pressure_is_verified(self):
        result = get_fallback("VAL-316-100")
        pressure = result.attributes[AttributeName.PRESSURE]
        assert pressure.status == AttributeStatus.VERIFIED
        assert pressure.value is not None
        assert "bar" in (pressure.value or "").lower()

    def test_material_contains_316(self):
        result = get_fallback("VAL-316-100")
        material = result.attributes[AttributeName.MATERIAL]
        assert material.value is not None
        assert "316" in material.value

    def test_temperature_range_has_both_bounds(self):
        result = get_fallback("VAL-316-100")
        temp = result.attributes[AttributeName.TEMPERATURE_RANGE]
        assert temp.value is not None, "temperature_range must not be null for verified product"
        assert "to" in (temp.value or "").lower() or "–" in (temp.value or "")

    def test_from_fallback_flag(self):
        result = get_fallback("VAL-316-100")
        assert result.from_fallback is True


# ─── GT-002: CONFLICT PRODUCT ────────────────────────────────────────────────

class TestConflictProduct:
    """GT-002 — VAL-316-100-C fixture has pressure conflict and needs_review."""

    def test_fixture_exists(self):
        assert has_fixture("VAL-316-100-C")

    def test_pipeline_status_is_needs_review(self):
        result = get_fallback("VAL-316-100-C")
        assert result.pipeline_status == "needs_review"

    def test_overall_confidence_capped_at_70(self):
        result = get_fallback("VAL-316-100-C")
        assert result.overall_confidence is not None
        assert result.overall_confidence <= 70, (
            f"Confidence must be capped at 70 due to conflict, got {result.overall_confidence}"
        )

    def test_pressure_status_is_conflict(self):
        result = get_fallback("VAL-316-100-C")
        pressure = result.attributes[AttributeName.PRESSURE]
        assert pressure.status == AttributeStatus.CONFLICT

    def test_pressure_conflict_has_summary(self):
        result = get_fallback("VAL-316-100-C")
        pressure = result.attributes[AttributeName.PRESSURE]
        assert pressure.conflict_summary is not None
        assert len(pressure.conflict_summary) > 10

    def test_pressure_conflict_severity_is_high(self):
        result = get_fallback("VAL-316-100-C")
        pressure = result.attributes[AttributeName.PRESSURE]
        assert pressure.conflict_severity is not None
        assert pressure.conflict_severity.value == "high"

    def test_pressure_has_two_candidates(self):
        result = get_fallback("VAL-316-100-C")
        pressure = result.attributes[AttributeName.PRESSURE]
        assert len(pressure.candidates) >= 2

    def test_pressure_candidates_contain_10_and_16_bar(self):
        result = get_fallback("VAL-316-100-C")
        pressure = result.attributes[AttributeName.PRESSURE]
        values = {c.value.lower() for c in pressure.candidates if c.value}
        assert any("10" in v for v in values), "Expected 10 bar candidate"
        assert any("16" in v for v in values), "Expected 16 bar candidate"

    def test_has_conflict_warning(self):
        result = get_fallback("VAL-316-100-C")
        codes = {w.code for w in result.warnings}
        assert "ATTRIBUTE_CONFLICT" in codes

    def test_non_conflict_attributes_are_verified(self):
        result = get_fallback("VAL-316-100-C")
        for attr_name in [AttributeName.CATEGORY, AttributeName.MATERIAL, AttributeName.CONNECTION]:
            attr = result.attributes[attr_name]
            assert attr.status == AttributeStatus.VERIFIED, (
                f"Expected {attr_name} to be verified, got {attr.status}"
            )


# ─── GT-003: MISSING EVIDENCE PRODUCT ───────────────────────────────────────

class TestMissingEvidenceProduct:
    """GT-003 — VAL-316-100-M has missing temperature; no hallucination."""

    def test_fixture_exists(self):
        assert has_fixture("VAL-316-100-M")

    def test_pipeline_status_is_needs_review(self):
        result = get_fallback("VAL-316-100-M")
        assert result.pipeline_status == "needs_review"

    def test_overall_confidence_capped_at_65(self):
        result = get_fallback("VAL-316-100-M")
        assert result.overall_confidence is not None
        assert result.overall_confidence <= 65

    def test_temperature_range_is_missing(self):
        """Core anti-hallucination assertion — temperature must be null."""
        result = get_fallback("VAL-316-100-M")
        temp = result.attributes[AttributeName.TEMPERATURE_RANGE]
        assert temp.status == AttributeStatus.MISSING
        assert temp.value is None, (
            f"HALLUCINATION DETECTED: temperature_range must be null, got '{temp.value}'"
        )
        assert temp.confidence is None

    def test_temperature_range_has_no_candidates(self):
        result = get_fallback("VAL-316-100-M")
        temp = result.attributes[AttributeName.TEMPERATURE_RANGE]
        assert len(temp.candidates) == 0

    def test_description_is_missing(self):
        result = get_fallback("VAL-316-100-M")
        desc = result.attributes[AttributeName.DESCRIPTION]
        assert desc.status == AttributeStatus.MISSING
        assert desc.value is None

    def test_connection_has_npt(self):
        result = get_fallback("VAL-316-100-M")
        conn = result.attributes[AttributeName.CONNECTION]
        assert conn.value is not None
        assert "NPT" in (conn.value or "").upper()

    def test_has_missing_warning(self):
        result = get_fallback("VAL-316-100-M")
        codes = {w.code for w in result.warnings}
        assert "ATTRIBUTE_MISSING" in codes


# ─── GT-004 / GT-007: TRUST GATE UNIT TESTS ─────────────────────────────────

class TestTrustGateScoring:
    """GT-004, GT-007 — confidence scoring and status assignment."""

    def test_marketplace_single_source_below_verified_threshold(self):
        """GT-004: Single marketplace_listing must not reach 'verified' (≥85)."""
        candidate = make_candidate(
            value="1000 PSI",
            source_type=SourceType.MARKETPLACE_LISTING,
            extraction_note="Product listing title",
            source_id="src-mkt-001",
        )
        conf, _ = score_candidate(
            attribute_name=AttributeName.PRESSURE,
            raw_candidate=candidate,
            extraction_tier=ExtractionTier.EXPLICIT_PROSE,
        )
        assert conf < 85, f"Marketplace single source scored {conf}, expected < 85"

    def test_datasheet_structured_field_high_confidence(self):
        """Manufacturer datasheet explicit field should score in verified range."""
        candidate = make_candidate(
            value="16 bar",
            source_type=SourceType.MANUFACTURER_DATASHEET,
            extraction_note="Specifications table — Pressure Rating: 16 bar",
        )
        conf, factors = score_candidate(
            attribute_name=AttributeName.PRESSURE,
            raw_candidate=candidate,
            extraction_tier=ExtractionTier.EXPLICIT_STRUCTURED_FIELD,
            agreeing_source_count=2,
        )
        assert conf >= 85, f"Datasheet structured field scored {conf}, expected ≥ 85"
        assert factors.source_authority_bonus == 20

    def test_null_candidate_produces_missing_status(self):
        """GT-007: All-null candidates → missing, not low_confidence."""
        status = assign_attribute_status(
            confidence=None,
            has_conflict=False,
            all_candidates_null=True,
        )
        assert status == AttributeStatus.MISSING, (
            f"Expected MISSING for all-null candidates, got {status}"
        )

    def test_conflict_overrides_high_score_to_conflict_status(self):
        """A high-scoring attribute with conflict must still be CONFLICT."""
        status = assign_attribute_status(
            confidence=95,
            has_conflict=True,
            all_candidates_null=False,
        )
        assert status == AttributeStatus.CONFLICT


# ─── GT-005 / GT-006: CONFLICT DETECTION ────────────────────────────────────

class TestConflictDetection:
    """GT-005, GT-006 — pressure conflict detection rules."""

    def test_pressure_conflict_above_5pct(self):
        """GT-005: 10 bar vs 16 bar = 60% difference → conflict."""
        candidates = [
            make_candidate("10 bar", source_id="src-ds", source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate("16 bar", source_id="src-dist", source_type=SourceType.DISTRIBUTOR_PAGE, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.PRESSURE, candidates)
        assert decision.has_conflict is True
        assert decision.conflict_type is not None
        assert decision.severity is not None
        assert decision.conflict_summary is not None

    def test_pressure_no_conflict_within_5pct(self):
        """GT-006: 10 bar vs 10.2 bar = 2% difference → no conflict."""
        candidates = [
            make_candidate("10 bar",   source_id="src-ds",   source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate("10.2 bar", source_id="src-auth",  source_type=SourceType.AUTHORIZED_DISTRIBUTOR, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.PRESSURE, candidates)
        assert decision.has_conflict is False

    def test_material_grade_conflict(self):
        """316 SS vs 304 SS is a grade mismatch → conflict."""
        candidates = [
            make_candidate("316 Stainless Steel", source_id="src-ds",   source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate("304 Stainless Steel", source_id="src-dist", source_type=SourceType.DISTRIBUTOR_PAGE, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.MATERIAL, candidates)
        assert decision.has_conflict is True

    def test_material_vague_vs_specific_no_conflict(self):
        """'Stainless Steel' vs '316 Stainless Steel' is ambiguity, not conflict."""
        candidates = [
            make_candidate("316 Stainless Steel", source_id="src-ds",   source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate("Stainless Steel",     source_id="src-dist", source_type=SourceType.DISTRIBUTOR_PAGE, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.MATERIAL, candidates)
        assert decision.has_conflict is False

    def test_connection_type_mismatch_is_conflict(self):
        """1/2 NPT vs 3/4 BSP → conflict."""
        candidates = [
            make_candidate('1/2" NPT', source_id="src-ds",   source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate("3/4 BSP",  source_id="src-dist", source_type=SourceType.DISTRIBUTOR_PAGE, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.CONNECTION, candidates)
        assert decision.has_conflict is True

    def test_single_candidate_never_conflicts(self):
        """One candidate cannot conflict with itself."""
        candidates = [make_candidate("16 bar")]
        decision = detect_conflict(AttributeName.PRESSURE, candidates)
        assert decision.has_conflict is False

    def test_null_candidate_ignored_in_conflict(self):
        """Null candidates are excluded from conflict detection."""
        candidates = [
            make_candidate("16 bar", source_id="src-ds", source_type=SourceType.MANUFACTURER_DATASHEET),
            make_candidate(None,     source_id="src-dist", source_type=SourceType.DISTRIBUTOR_PAGE, evidence_id="ev-002"),
        ]
        decision = detect_conflict(AttributeName.PRESSURE, candidates)
        assert decision.has_conflict is False


# ─── GT-008 / GT-009: AI EXTRACTOR INTEGRATION ───────────────────────────────

class TestAiExtractorMode:
    """GT-008, GT-009 — mock mode and live fallback behaviour."""

    def test_mock_mode_returns_fixture_without_calling_gemini(self, product_verified, source_datasheet):
        """GT-008: AI_MODE=mock must never call _call_gemini."""
        from app.services import ai_extractor

        with patch.dict(os.environ, {"AI_MODE": "mock"}):
            # Reload the module-level constant
            ai_extractor.AI_MODE = "mock"

            with patch.object(ai_extractor, "_call_gemini") as mock_gemini:
                result = ai_extractor.extract_product_intelligence(
                    product=product_verified,
                    sources=[source_datasheet],
                    evidence=[],
                )

            mock_gemini.assert_not_called()
            assert result.from_fallback is True
            assert result.pipeline_status in ("ready", "needs_review")

    def test_live_mode_retries_twice_then_falls_back(self, product_verified, source_datasheet):
        """GT-009: Two LLM failures → from_fallback=True, gemini called exactly 2x."""
        from app.services import ai_extractor

        evidence = [EvidenceInput(
            evidence_id="ev-001",
            source_id="src-acme-ds-100",
            source_type=SourceType.MANUFACTURER_DATASHEET,
            raw_text="Body Material: CF8M (316 SS). Pressure: 16 bar. Temp: -20°C to +200°C.",
            retrieved_at="2026-08-19T08:11:00Z",
        )]

        call_count = {"n": 0}

        def failing_gemini(_prompt: str) -> str:
            call_count["n"] += 1
            raise RuntimeError("Simulated LLM failure")

        with patch.dict(os.environ, {"AI_MODE": "live"}):
            ai_extractor.AI_MODE = "live"
            with patch.object(ai_extractor, "_call_gemini", side_effect=failing_gemini):
                result = ai_extractor.extract_product_intelligence(
                    product=product_verified,
                    sources=[source_datasheet],
                    evidence=evidence,
                )

        assert call_count["n"] == 2, f"Expected 2 LLM calls, got {call_count['n']}"
        assert result.from_fallback is True


# ─── PRODUCT CONFIDENCE INTEGRATION ─────────────────────────────────────────

class TestProductConfidence:
    """Validate compute_product_confidence caps and status logic."""

    def _make_verified_attrs(self):
        """Return a dict of all-verified attributes at confidence 95."""
        from app.schemas.enrichment import EnrichedAttribute, ScoreFactors
        sf = ScoreFactors(
            model_confidence=70, source_authority_bonus=20,
            evidence_quality_bonus=10, agreement_bonus=6,
            conflict_penalty=0, ambiguity_penalty=0,
            raw=106, clamped=95,
        )
        attrs = {}
        for attr in AttributeName:
            attrs[attr] = EnrichedAttribute(
                name=attr, value="test value",
                status=AttributeStatus.VERIFIED, confidence=95,
                winning_source_id="src-001", score_factors=sf, candidates=[],
            )
        return attrs

    def test_all_verified_high_confidence_is_ready(self):
        attrs = self._make_verified_attrs()
        conf, status = compute_product_confidence(attrs)
        assert status == "ready"
        assert conf >= 85

    def test_pressure_conflict_caps_at_70_and_needs_review(self):
        from app.schemas.enrichment import EnrichedAttribute
        attrs = self._make_verified_attrs()
        attrs[AttributeName.PRESSURE] = EnrichedAttribute(
            name=AttributeName.PRESSURE,
            value="10 bar",
            status=AttributeStatus.CONFLICT,
            confidence=62,
            winning_source_id="src-001",
            conflict_summary="10 bar vs 16 bar",
            candidates=[],
            score_factors=None,
        )
        conf, status = compute_product_confidence(attrs)
        assert conf <= 70
        assert status == "needs_review"

    def test_temperature_missing_caps_at_65_and_needs_review(self):
        from app.schemas.enrichment import EnrichedAttribute
        attrs = self._make_verified_attrs()
        attrs[AttributeName.TEMPERATURE_RANGE] = EnrichedAttribute(
            name=AttributeName.TEMPERATURE_RANGE,
            value=None,
            status=AttributeStatus.MISSING,
            confidence=None,
            winning_source_id=None,
            candidates=[],
            score_factors=None,
        )
        conf, status = compute_product_confidence(attrs)
        assert conf <= 65
        assert status == "needs_review"
