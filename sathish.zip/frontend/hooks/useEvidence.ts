/**
 * useEvidence.ts
 * DeliverFlow — evidence query hook.
 *
 * Fetches raw evidence records for a product, with optional source_type filter.
 * Used by the Evidence Viewer panel in the product detail page.
 *
 * Usage:
 *   const { data, isLoading } = useEvidence(productId);
 *   const { data } = useEvidence(productId, { sourceType: "manufacturer_datasheet" });
 *
 *   // Map evidence_id → Evidence for use in attribute candidate panels:
 *   const evidenceMap = useEvidenceMap(productId);
 *   const record = evidenceMap.get("ev-001");
 */

"use client";

import { useQuery } from "@tanstack/react-query";
import { api, ApiClientError } from "@/lib/api";
import type { EvidenceListResponse, SourceType, Evidence } from "@/lib/types";
import { productKeys } from "./useCreateProduct";

// ─── QUERY KEY ───────────────────────────────────────────────────────────────

const evidenceKeys = {
  list:     (id: string, sourceType?: SourceType) =>
    [...productKeys.evidence(id), { sourceType }] as const,
};

// ─── HOOK ────────────────────────────────────────────────────────────────────

interface UseEvidenceOptions {
  sourceType?: SourceType;
  /** Only fetch when true. Default: true. */
  enabled?: boolean;
}

export function useEvidence(productId: string, options: UseEvidenceOptions = {}) {
  const { sourceType, enabled = true } = options;

  return useQuery<EvidenceListResponse, ApiClientError | Error>({
    queryKey: evidenceKeys.list(productId, sourceType),
    queryFn:  () => api.getEvidence(productId, sourceType),
    enabled:  !!productId && enabled,
    staleTime: 5 * 60 * 1_000,     // evidence doesn't change — 5 min cache

    retry: (failureCount, error) => {
      if (error instanceof ApiClientError && error.status < 500) return false;
      return failureCount < 2;
    },
  });
}

// ─── DERIVED: EVIDENCE MAP ────────────────────────────────────────────────────

/**
 * Returns a Map<evidence_id, Evidence> for O(1) lookup from attribute candidates.
 * Useful when rendering the evidence snippet alongside each candidate value.
 */
export function useEvidenceMap(
  productId: string,
  options: UseEvidenceOptions = {}
): Map<string, Evidence> {
  const { data } = useEvidence(productId, options);

  if (!data?.evidence) return new Map();

  return new Map(data.evidence.map((ev) => [ev.id, ev]));
}
