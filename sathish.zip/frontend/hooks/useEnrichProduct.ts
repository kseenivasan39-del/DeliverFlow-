/**
 * useEnrichProduct.ts
 * DeliverFlow — enrichment trigger + polling hook.
 *
 * Exports two hooks:
 *
 *   useEnrichProduct(productId)
 *     Mutation that triggers POST /products/{id}/enrich.
 *     Call .mutate() to start the pipeline.
 *
 *   useProductStatus(productId, options)
 *     Query that polls GET /products/{id} until the pipeline reaches
 *     a terminal state (completed, needs_review, failed, ready).
 *     Used to drive the live pipeline progress UI.
 *
 * Usage:
 *   const { mutate: enrich, isPending } = useEnrichProduct(productId);
 *   const { data: product, isPolling } = useProductStatus(productId, { enabled: true });
 */

"use client";

import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { api, ApiClientError } from "@/lib/api";
import { PipelineStatus } from "@/lib/types";
import type { Product, EnrichRequest, EnrichmentResult } from "@/lib/types";
import { productKeys } from "./useCreateProduct";

// ─── CONSTANTS ───────────────────────────────────────────────────────────────

/** Polling interval while pipeline is running (ms) */
const POLL_INTERVAL_MS = 2_500;

/** Terminal states — polling stops when product reaches one of these */
const TERMINAL_STATUSES = new Set<string>([
  PipelineStatus.COMPLETED,
  PipelineStatus.NEEDS_REVIEW,
  PipelineStatus.FAILED,
  "ready",
]);

// ─── ENRICH MUTATION ─────────────────────────────────────────────────────────

interface UseEnrichProductOptions {
  onSuccess?: (result: EnrichmentResult) => void;
  onError?:   (error: ApiClientError | Error) => void;
}

export function useEnrichProduct(
  productId: string,
  options: UseEnrichProductOptions = {}
) {
  const queryClient = useQueryClient();

  return useMutation<EnrichmentResult, ApiClientError | Error, EnrichRequest>({
    mutationFn: (body = {}) => api.enrichProduct(productId, body),

    onSuccess: (result) => {
      // Optimistically update the cached product's pipeline_status
      queryClient.setQueryData<Product>(
        productKeys.detail(productId),
        (prev) =>
          prev
            ? {
                ...prev,
                status:         result.pipeline_status,
                pipeline_status: result.pipeline_status,
                current_step:   result.current_step,
              }
            : prev
      );
      options.onSuccess?.(result);
    },

    onError: (error) => {
      options.onError?.(error);
    },
  });
}

// ─── PRODUCT STATUS QUERY (with polling) ─────────────────────────────────────

interface UseProductStatusOptions {
  /** Set to true once the enrichment mutation has fired */
  enabled?: boolean;
}

export function useProductStatus(
  productId: string,
  options: UseProductStatusOptions = {}
) {
  const { enabled = false } = options;

  const query = useQuery<Product, ApiClientError | Error>({
    queryKey: productKeys.detail(productId),
    queryFn:  () => api.getProduct(productId),
    enabled,

    // Refetch every 2.5s while the pipeline is running
    refetchInterval: (query) => {
      const status = query.state.data?.status ?? query.state.data?.pipeline_status;
      if (!status) return POLL_INTERVAL_MS;
      return TERMINAL_STATUSES.has(status) ? false : POLL_INTERVAL_MS;
    },

    // Don't mark as stale while we're actively polling
    staleTime: 0,

    // Retry on network errors, but not on 4xx
    retry: (failureCount, error) => {
      if (error instanceof ApiClientError && error.status < 500) return false;
      return failureCount < 3;
    },
  });

  const status = query.data?.status ?? query.data?.pipeline_status;
  const isPolling = enabled && !!status && !TERMINAL_STATUSES.has(status);
  const isTerminal = !!status && TERMINAL_STATUSES.has(status);

  return {
    ...query,
    isPolling,
    isTerminal,
    pipelineStatus: status ?? null,
    currentStep:    query.data?.current_step ?? null,
  };
}

// ─── REVIEW MUTATION ─────────────────────────────────────────────────────────

export function useSubmitReview(productId: string) {
  const queryClient = useQueryClient();

  return useMutation<Product, ApiClientError | Error, Parameters<typeof api.submitReview>[1]>({
    mutationFn: (body) => api.submitReview(productId, body),

    onSuccess: (updatedProduct) => {
      queryClient.setQueryData(productKeys.detail(productId), updatedProduct);
    },

    onError: (error) => {
      // Invalidate on error to ensure we re-sync with server state
      queryClient.invalidateQueries({ queryKey: productKeys.detail(productId) });
      console.error("[DeliverFlow] Review submission failed:", error);
    },
  });
}

// ─── EXPORT HELPERS ──────────────────────────────────────────────────────────

export function useExportJson(productId: string) {
  return useMutation<void, ApiClientError | Error, void>({
    mutationFn: async () => {
      const data = await api.exportJson(productId);
      const blob = new Blob([JSON.stringify(data, null, 2)], {
        type: "application/json",
      });
      triggerDownload(blob, `${productId}.json`);
    },
  });
}

export function useExportCsv(productId: string) {
  return useMutation<void, ApiClientError | Error, void>({
    mutationFn: async () => {
      const blob = await api.exportCsv(productId);
      triggerDownload(blob, `${productId}.csv`);
    },
  });
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
