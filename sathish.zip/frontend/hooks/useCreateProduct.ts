/**
 * useCreateProduct.ts
 * DeliverFlow — mutation hook for creating a new product record.
 *
 * Usage:
 *   const { mutate, isPending, error } = useCreateProduct();
 *   mutate({ mpn, brand, description }, { onSuccess: (product) => router.push(`/products/${product.product_id}`) });
 */

"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { api, ApiClientError, isApiError } from "@/lib/api";
import { CreateProductRequestSchema } from "@/lib/schema";
import type { Product, CreateProductRequest } from "@/lib/types";

// ─── QUERY KEYS ──────────────────────────────────────────────────────────────

/** Centralised query key factory — import these in all hooks for consistency. */
export const productKeys = {
  all:      ()         => ["products"] as const,
  detail:   (id: string) => ["products", id] as const,
  evidence: (id: string) => ["products", id, "evidence"] as const,
} as const;

// ─── HOOK ────────────────────────────────────────────────────────────────────

interface UseCreateProductOptions {
  onSuccess?: (product: Product) => void;
  onError?:   (error: ApiClientError | Error) => void;
}

export function useCreateProduct(options: UseCreateProductOptions = {}) {
  const queryClient = useQueryClient();

  return useMutation<Product, ApiClientError | Error, CreateProductRequest>({
    mutationFn: async (input) => {
      // Validate input before sending to avoid round-trip on obvious errors
      const parsed = CreateProductRequestSchema.safeParse(input);
      if (!parsed.success) {
        const firstError = parsed.error.errors[0];
        throw new Error(
          `Invalid input: ${firstError?.path.join(".") ?? "unknown"} — ${firstError?.message ?? "validation error"}`
        );
      }
      return api.createProduct(parsed.data);
    },

    onSuccess: (product) => {
      // Seed the query cache so getProduct doesn't need a round-trip
      queryClient.setQueryData(productKeys.detail(product.product_id), product);
      options.onSuccess?.(product);
    },

    onError: (error) => {
      if (isApiError(error) && error.status === 409) {
        console.warn(
          `[DeliverFlow] MPN already exists — product not created. ` +
          `Use existing product_id or force a new enrichment run.`
        );
      }
      options.onError?.(error);
    },
  });
}
