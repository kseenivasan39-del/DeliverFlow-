/**
 * api.ts
 * DeliverFlow — typed API client.
 *
 * Usage:
 *   import { api } from "@/lib/api";
 *   const product = await api.getProduct("prod-val-316-100");
 *
 * Mode:
 *   NEXT_PUBLIC_API_MODE=live  → calls real FastAPI backend
 *   NEXT_PUBLIC_API_MODE=mock  → MSW intercepts in browser; fallback fixtures in tests
 *
 * Error handling:
 *   All functions throw ApiClientError on non-2xx responses.
 *   Use isApiError(e) in catch blocks to narrow the type.
 */

import type {
  Product,
  CreateProductRequest,
  EnrichRequest,
  EnrichmentResult,
  EvidenceListResponse,
  ReviewRequest,
  ProductExport,
  SourceType,
  ApiError,
} from "./types";

import { ProductSchema, EnrichmentResultSchema, EvidenceListResponseSchema } from "./schema";
import type { ZodSchema } from "zod";

// ─── CONFIG ──────────────────────────────────────────────────────────────────

const API_BASE =
  process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

const IS_MOCK_MODE =
  process.env.NEXT_PUBLIC_API_MODE === "mock";

// ─── ERROR CLASS ─────────────────────────────────────────────────────────────

export class ApiClientError extends Error {
  readonly code: string;
  readonly status: number;
  readonly details: Record<string, unknown> | null;

  constructor(payload: ApiError) {
    super(payload.message);
    this.name = "ApiClientError";
    this.code = payload.error;
    this.status = payload.status;
    this.details = payload.details ?? null;
  }
}

export function isApiError(error: unknown): error is ApiClientError {
  return error instanceof ApiClientError;
}

// ─── FETCH WRAPPER ───────────────────────────────────────────────────────────

interface FetchOptions extends Omit<RequestInit, "body"> {
  body?: unknown;
  schema?: ZodSchema;
}

async function apiFetch<T>(path: string, options: FetchOptions = {}): Promise<T> {
  const { body, schema, ...init } = options;

  const response = await fetch(`${API_BASE}${path}`, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
      ...init.headers,
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  // Handle non-JSON or empty responses (e.g. 204 No Content)
  const contentType = response.headers.get("content-type") ?? "";
  const isJson = contentType.includes("application/json");

  if (!response.ok) {
    let errorPayload: ApiError;
    if (isJson) {
      const raw = await response.json();
      errorPayload = {
        error:   raw.error   ?? "unknown_error",
        message: raw.message ?? `Request failed with status ${response.status}`,
        details: raw.details ?? null,
        status:  response.status,
      };
    } else {
      errorPayload = {
        error:   "network_error",
        message: `Unexpected response: ${response.status} ${response.statusText}`,
        details: null,
        status:  response.status,
      };
    }
    throw new ApiClientError(errorPayload);
  }

  if (response.status === 204 || !isJson) {
    return undefined as unknown as T;
  }

  const data = await response.json();

  // Validate shape in development or when a schema is provided
  if (schema && process.env.NODE_ENV !== "production") {
    const result = schema.safeParse(data);
    if (!result.success) {
      console.warn(
        `[DeliverFlow API] Response validation warning on ${path}:`,
        result.error.flatten()
      );
      // Warn but don't throw — backend may have additive fields
    }
  }

  return data as T;
}

// ─── CSV HELPER ──────────────────────────────────────────────────────────────

async function fetchCsv(path: string): Promise<Blob> {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { Accept: "text/csv" },
  });
  if (!response.ok) {
    throw new ApiClientError({
      error:   "export_failed",
      message: `CSV export failed: ${response.status} ${response.statusText}`,
      details: null,
      status:  response.status,
    });
  }
  return response.blob();
}

// ─── API CLIENT ──────────────────────────────────────────────────────────────

export const api = {
  /**
   * POST /products
   * Create a new product record. Does not trigger enrichment.
   */
  createProduct(body: CreateProductRequest): Promise<Product> {
    return apiFetch<Product>("/products", {
      method: "POST",
      body,
      schema: ProductSchema,
    });
  },

  /**
   * GET /products/{id}
   * Fetch a product record with all attributes and pipeline status.
   * Use this to poll for pipeline completion.
   */
  getProduct(id: string): Promise<Product> {
    return apiFetch<Product>(`/products/${id}`, {
      method: "GET",
      schema: ProductSchema,
    });
  },

  /**
   * POST /products/{id}/enrich
   * Trigger the AI enrichment pipeline. Returns immediately with pipeline status.
   */
  enrichProduct(id: string, body: EnrichRequest = {}): Promise<EnrichmentResult> {
    return apiFetch<EnrichmentResult>(`/products/${id}/enrich`, {
      method: "POST",
      body,
      schema: EnrichmentResultSchema,
    });
  },

  /**
   * GET /products/{id}/evidence
   * List all evidence records for a product. Optional source_type filter.
   */
  getEvidence(id: string, sourceType?: SourceType): Promise<EvidenceListResponse> {
    const params = sourceType ? `?source_type=${sourceType}` : "";
    return apiFetch<EvidenceListResponse>(`/products/${id}/evidence${params}`, {
      method: "GET",
      schema: EvidenceListResponseSchema,
    });
  },

  /**
   * POST /products/{id}/review
   * Submit human review actions for one or more flagged attributes.
   */
  submitReview(id: string, body: ReviewRequest): Promise<Product> {
    return apiFetch<Product>(`/products/${id}/review`, {
      method: "POST",
      body,
      schema: ProductSchema,
    });
  },

  /**
   * GET /products/{id}/export/json
   * Download the verified product record as JSON.
   */
  exportJson(id: string): Promise<ProductExport> {
    return apiFetch<ProductExport>(`/products/${id}/export/json`, {
      method: "GET",
    });
  },

  /**
   * GET /products/{id}/export/csv
   * Download the verified product record as a CSV Blob.
   * Caller is responsible for triggering the browser download.
   */
  exportCsv(id: string): Promise<Blob> {
    return fetchCsv(`/products/${id}/export/csv`);
  },
} as const;

// ─── EXPORT MODE FLAG ────────────────────────────────────────────────────────

export { IS_MOCK_MODE };
