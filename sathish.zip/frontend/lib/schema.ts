/**
 * schema.ts
 * DeliverFlow — Zod runtime validation schemas.
 *
 * These schemas validate API responses at the boundary.
 * They mirror types.ts but are Zod objects — use z.infer<typeof Schema>
 * to derive types when needed. For the main app, prefer the hand-written
 * types in types.ts (they're more readable); use schemas for safeParse at
 * the API client layer.
 */

import { z } from "zod";

// ─── ENUM SCHEMAS ─────────────────────────────────────────────────────────────

export const PipelineStepSchema = z.enum([
  "discovering_sources",
  "retrieving_evidence",
  "extracting_attributes",
  "validating_values",
  "assigning_confidence",
  "preparing_product_record",
]);

export const PipelineStatusSchema = z.enum([
  "pending",
  "running",
  "needs_review",
  "completed",
  "failed",
]);

export const AttributeNameSchema = z.enum([
  "category",
  "material",
  "pressure",
  "connection",
  "temperature_range",
  "description",
]);

export const SourceTypeSchema = z.enum([
  "manufacturer_datasheet",
  "official_product_page",
  "authorized_distributor",
  "distributor_page",
  "marketplace_listing",
]);

export const AttributeStatusSchema = z.enum([
  "verified",
  "low_confidence",
  "conflict",
  "missing",
  "needs_review",
  "accepted",
  "edited",
  "rejected",
  "unknown",
]);

export const ReviewActionTypeSchema = z.enum(["accept", "edit", "reject"]);

export const WarningSeveritySchema = z.enum(["low", "medium", "high"]);

// ─── SOURCE ──────────────────────────────────────────────────────────────────

export const SourceSchema = z.object({
  id: z.string(),
  url: z.string().url(),
  source_type: SourceTypeSchema,
  domain: z.string().nullable(),
  title: z.string().nullable(),
  authority_score: z.number().min(0).max(1),
  trust_label: z.string(),
  discovered_at: z.string(),
  evidence_id: z.string().optional(),
});

// ─── EVIDENCE ────────────────────────────────────────────────────────────────

export const EvidenceSchema = z.object({
  id: z.string(),
  product_id: z.string(),
  source: SourceSchema,
  raw_text: z.string(),
  retrieved_at: z.string(),
  extraction_error: z.string().nullable(),
});

export const EvidenceListResponseSchema = z.object({
  product_id: z.string(),
  evidence: z.array(EvidenceSchema),
  total: z.number().int().nonnegative(),
});

// ─── ATTRIBUTE ───────────────────────────────────────────────────────────────

export const ScoreFactorsSchema = z.object({
  model_confidence:       z.number(),
  source_authority_bonus: z.number(),
  evidence_quality_bonus: z.number(),
  agreement_bonus:        z.number(),
  conflict_penalty:       z.number(),
  ambiguity_penalty:      z.number(),
  raw:                    z.number().optional(),
  clamped:                z.number(),
  status_override:        z.string().optional(),
}).nullable();

export const CandidateValueSchema = z.object({
  value:          z.string(),
  normalized_from: z.string().optional(),
  normalized_bar:  z.number().optional(),
  min_celsius:     z.number().optional(),
  max_celsius:     z.number().optional(),
  source_id:       z.string(),
  source_type:     SourceTypeSchema,
  authority_score: z.number().min(0).max(1),
  evidence_id:     z.string(),
  extraction_note: z.string().nullable(),
});

export const AttributeSchema = z.object({
  name:                      AttributeNameSchema,
  value:                     z.string().nullable(),
  status:                    AttributeStatusSchema,
  confidence:                z.number().int().min(0).max(99).nullable(),
  winning_source_id:         z.string().nullable(),
  conflict_type:             z.string().nullish(),
  conflict_severity:         WarningSeveritySchema.nullish(),
  conflict_summary:          z.string().nullish(),
  missing_reason:            z.string().nullish(),
  missing_explanation:       z.string().nullish(),
  score_factors:             ScoreFactorsSchema,
  generation_method:         z.string().optional(),
  generated_from_attributes: z.array(AttributeNameSchema).optional(),
  candidates:                z.array(CandidateValueSchema),
  min_celsius:               z.number().nullable().optional(),
  max_celsius:               z.number().nullable().optional(),
  normalized_bar:            z.number().nullable().optional(),
});

// ─── PIPELINE ────────────────────────────────────────────────────────────────

export const PipelineStepResultSchema = z.object({
  step:                       PipelineStepSchema,
  status:                     z.enum(["pending", "running", "completed", "failed"]),
  sources_found:              z.number().optional(),
  evidence_retrieved:         z.number().optional(),
  errors:                     z.number().optional(),
  error_detail:               z.string().optional(),
  candidates_extracted:       z.number().optional(),
  invalid_candidates:         z.number().optional(),
  conflicts_detected:         z.number().optional(),
  missing_attributes:         z.array(AttributeNameSchema).optional(),
  attributes_needing_review:  z.number().optional(),
  confidence_cap_applied:     z.boolean().optional(),
  cap_reason:                 z.string().optional(),
  started_at:                 z.string().optional(),
  completed_at:               z.string().optional(),
});

export const PipelineRunSchema = z.object({
  run_id:           z.string(),
  triggered_at:     z.string(),
  completed_at:     z.string().nullable(),
  duration_seconds: z.number().nullable(),
  steps:            z.array(PipelineStepResultSchema),
});

// ─── WARNINGS ────────────────────────────────────────────────────────────────

export const ProductWarningSchema = z.object({
  code:                z.string(),
  attribute:           z.union([AttributeNameSchema, z.literal("product")]).optional(),
  severity:            WarningSeveritySchema,
  message:             z.string(),
  conflict_type:       z.string().optional(),
  sources_in_conflict: z.array(z.string()).optional(),
  missing_reason:      z.string().optional(),
  url:                 z.string().optional(),
  http_status:         z.number().optional(),
  raw_score:           z.number().optional(),
  cap:                 z.number().optional(),
  effective_score:     z.number().optional(),
});

// ─── PRODUCT ─────────────────────────────────────────────────────────────────

export const ProductSchema = z.object({
  product_id:         z.string(),
  mpn:                z.string(),
  brand:              z.string(),
  input_description:  z.string().optional(),
  status:             PipelineStatusSchema,
  overall_confidence: z.number().int().min(0).max(99).nullable(),
  validation_status:  z.string(),
  pipeline:           PipelineRunSchema,
  sources:            z.array(SourceSchema),
  attributes:         z.record(AttributeNameSchema, AttributeSchema),
  warnings:           z.array(ProductWarningSchema),
  // Legacy / list response fields
  pipeline_status:    PipelineStatusSchema.optional(),
  current_step:       PipelineStepSchema.nullable().optional(),
  source_count:       z.number().optional(),
  evidence_count:     z.number().optional(),
  needs_review_count: z.number().optional(),
  enriched_at:        z.string().nullable().optional(),
  created_at:         z.string().optional(),
  updated_at:         z.string().optional(),
});

// ─── REQUEST SCHEMAS ─────────────────────────────────────────────────────────

export const CreateProductRequestSchema = z.object({
  mpn:         z.string().min(2).max(100),
  brand:       z.string().min(1).max(100),
  description: z.string().min(5).max(500),
});

export const ReviewActionSchema = z.object({
  attribute_name: AttributeNameSchema,
  action:         ReviewActionTypeSchema,
  edited_value:   z.string().nullable().optional(),
  reviewer_note:  z.string().nullable().optional(),
  reviewed_by:    z.string().nullable().optional(),
});

export const ReviewRequestSchema = z.object({
  actions: z.array(ReviewActionSchema).min(1),
});

export const EnrichRequestSchema = z.object({
  force:                z.boolean().optional(),
  source_types:         z.array(SourceTypeSchema).optional(),
  confidence_threshold: z.number().min(0).max(1).optional(),
});

// ─── ENRICHMENT RESULT ───────────────────────────────────────────────────────

export const EnrichmentResultSchema = z.object({
  product_id:       z.string(),
  pipeline_status:  PipelineStatusSchema,
  current_step:     PipelineStepSchema,
  started_at:       z.string(),
  estimated_seconds: z.number().optional(),
});

// ─── API ERROR ───────────────────────────────────────────────────────────────

export const ApiErrorSchema = z.object({
  error:   z.string(),
  message: z.string(),
  details: z.record(z.unknown()).nullable().optional(),
  status:  z.number(),
});

// ─── INFERRED TYPES (for convenience) ────────────────────────────────────────

export type CreateProductRequestInput = z.input<typeof CreateProductRequestSchema>;
export type ReviewActionInput         = z.input<typeof ReviewActionSchema>;
export type ReviewRequestInput        = z.input<typeof ReviewRequestSchema>;
export type EnrichRequestInput        = z.input<typeof EnrichRequestSchema>;
