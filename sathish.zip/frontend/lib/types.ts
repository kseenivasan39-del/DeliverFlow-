/**
 * types.ts
 * DeliverFlow — canonical TypeScript types.
 *
 * All types mirror the OpenAPI 3.1 contract at contracts/openapi.yaml.
 * Never diverge from the contract — run `npm run generate:types` to regenerate
 * from the spec if the contract changes.
 */

// ─── ENUMS ───────────────────────────────────────────────────────────────────

export const PipelineStep = {
  DISCOVERING_SOURCES:      "discovering_sources",
  RETRIEVING_EVIDENCE:      "retrieving_evidence",
  EXTRACTING_ATTRIBUTES:    "extracting_attributes",
  VALIDATING_VALUES:        "validating_values",
  ASSIGNING_CONFIDENCE:     "assigning_confidence",
  PREPARING_PRODUCT_RECORD: "preparing_product_record",
} as const;
export type PipelineStep = (typeof PipelineStep)[keyof typeof PipelineStep];

export const PipelineStatus = {
  PENDING:      "pending",
  RUNNING:      "running",
  NEEDS_REVIEW: "needs_review",
  COMPLETED:    "completed",
  FAILED:       "failed",
} as const;
export type PipelineStatus = (typeof PipelineStatus)[keyof typeof PipelineStatus];

export const AttributeName = {
  CATEGORY:          "category",
  MATERIAL:          "material",
  PRESSURE:          "pressure",
  CONNECTION:        "connection",
  TEMPERATURE_RANGE: "temperature_range",
  DESCRIPTION:       "description",
} as const;
export type AttributeName = (typeof AttributeName)[keyof typeof AttributeName];

/** Ordered list — used for consistent attribute rendering order in the UI. */
export const ATTRIBUTE_ORDER: AttributeName[] = [
  AttributeName.CATEGORY,
  AttributeName.MATERIAL,
  AttributeName.PRESSURE,
  AttributeName.CONNECTION,
  AttributeName.TEMPERATURE_RANGE,
  AttributeName.DESCRIPTION,
];

export const SourceType = {
  MANUFACTURER_DATASHEET: "manufacturer_datasheet",
  OFFICIAL_PRODUCT_PAGE:  "official_product_page",
  AUTHORIZED_DISTRIBUTOR: "authorized_distributor",
  DISTRIBUTOR_PAGE:       "distributor_page",
  MARKETPLACE_LISTING:    "marketplace_listing",
} as const;
export type SourceType = (typeof SourceType)[keyof typeof SourceType];

export const AttributeStatus = {
  VERIFIED:       "verified",
  LOW_CONFIDENCE: "low_confidence",
  CONFLICT:       "conflict",
  MISSING:        "missing",
  NEEDS_REVIEW:   "needs_review",
  ACCEPTED:       "accepted",
  EDITED:         "edited",
  REJECTED:       "rejected",
  UNKNOWN:        "unknown",
} as const;
export type AttributeStatus = (typeof AttributeStatus)[keyof typeof AttributeStatus];

export const ReviewActionType = {
  ACCEPT: "accept",
  EDIT:   "edit",
  REJECT: "reject",
} as const;
export type ReviewActionType = (typeof ReviewActionType)[keyof typeof ReviewActionType];

// ─── SOURCE ──────────────────────────────────────────────────────────────────

export interface Source {
  id: string;
  url: string;
  source_type: SourceType;
  domain: string | null;
  title: string | null;
  authority_score: number;          // 0.0–1.0
  trust_label: string;
  discovered_at: string;            // ISO 8601
  evidence_id?: string;
}

// ─── EVIDENCE ────────────────────────────────────────────────────────────────

export interface Evidence {
  id: string;
  product_id: string;
  source: Source;
  raw_text: string;
  retrieved_at: string;
  extraction_error: string | null;
}

export interface EvidenceListResponse {
  product_id: string;
  evidence: Evidence[];
  total: number;
}

// ─── ATTRIBUTE ───────────────────────────────────────────────────────────────

export interface ScoreFactors {
  model_confidence: number;
  source_authority_bonus: number;
  evidence_quality_bonus: number;
  agreement_bonus: number;
  conflict_penalty: number;
  ambiguity_penalty: number;
  raw?: number;
  clamped: number;
  status_override?: string;
}

export interface CandidateValue {
  value: string;
  normalized_from?: string;
  normalized_bar?: number;
  min_celsius?: number;
  max_celsius?: number;
  source_id: string;
  source_type: SourceType;
  authority_score: number;
  evidence_id: string;
  extraction_note: string | null;
}

export interface Attribute {
  name: AttributeName;
  value: string | null;
  status: AttributeStatus;
  confidence: number | null;        // 0–99; null when missing
  winning_source_id: string | null;
  conflict_type?: string | null;
  conflict_severity?: "low" | "medium" | "high" | null;
  conflict_summary?: string | null;
  missing_reason?: string | null;
  missing_explanation?: string | null;
  score_factors: ScoreFactors | null;
  generation_method?: string;
  generated_from_attributes?: AttributeName[];
  candidates: CandidateValue[];
  // Temperature-specific
  min_celsius?: number | null;
  max_celsius?: number | null;
  // Pressure-specific
  normalized_bar?: number | null;
}

// ─── REVIEW ──────────────────────────────────────────────────────────────────

export interface ReviewAction {
  attribute_name: AttributeName;
  action: ReviewActionType;
  edited_value?: string | null;
  reviewer_note?: string | null;
  reviewed_by?: string | null;
}

export interface ReviewRequest {
  actions: ReviewAction[];
}

// ─── PIPELINE ────────────────────────────────────────────────────────────────

export interface PipelineStepResult {
  step: PipelineStep;
  status: "pending" | "running" | "completed" | "failed";
  sources_found?: number;
  evidence_retrieved?: number;
  errors?: number;
  error_detail?: string;
  candidates_extracted?: number;
  invalid_candidates?: number;
  conflicts_detected?: number;
  missing_attributes?: AttributeName[];
  attributes_needing_review?: number;
  confidence_cap_applied?: boolean;
  cap_reason?: string;
  started_at?: string;
  completed_at?: string;
}

export interface PipelineRun {
  run_id: string;
  triggered_at: string;
  completed_at: string | null;
  duration_seconds: number | null;
  steps: PipelineStepResult[];
}

// ─── WARNINGS ────────────────────────────────────────────────────────────────

export interface ProductWarning {
  code: string;
  attribute?: AttributeName | "product";
  severity: "low" | "medium" | "high";
  message: string;
  conflict_type?: string;
  sources_in_conflict?: string[];
  missing_reason?: string;
  url?: string;
  http_status?: number;
  raw_score?: number;
  cap?: number;
  effective_score?: number;
}

// ─── PRODUCT ─────────────────────────────────────────────────────────────────

export interface Product {
  product_id: string;
  mpn: string;
  brand: string;
  input_description?: string;
  status: PipelineStatus;
  overall_confidence: number | null;
  validation_status: string;
  pipeline: PipelineRun;
  sources: Source[];
  attributes: Record<AttributeName, Attribute>;
  warnings: ProductWarning[];
  // Legacy fields from list/create response
  pipeline_status?: PipelineStatus;
  current_step?: PipelineStep | null;
  source_count?: number;
  evidence_count?: number;
  needs_review_count?: number;
  enriched_at?: string | null;
  created_at?: string;
  updated_at?: string;
}

// ─── REQUEST / RESPONSE SHAPES ───────────────────────────────────────────────

export interface CreateProductRequest {
  mpn: string;
  brand: string;
  description: string;
}

export interface EnrichRequest {
  force?: boolean;
  source_types?: SourceType[];
  confidence_threshold?: number;
}

export interface EnrichmentResult {
  product_id: string;
  pipeline_status: PipelineStatus;
  current_step: PipelineStep;
  started_at: string;
  estimated_seconds?: number;
}

export interface ExportAttributeEntry {
  value: string;
  status: AttributeStatus;
  confidence_score: number | null;
  source_url: string | null;
}

export interface ProductExport {
  mpn: string;
  brand: string;
  pipeline_status: PipelineStatus;
  attributes: Record<string, ExportAttributeEntry>;
  exported_at: string;
}

// ─── API ERROR ───────────────────────────────────────────────────────────────

export interface ApiError {
  error: string;                    // machine-readable code
  message: string;                  // human-readable description
  details?: Record<string, unknown> | null;
  status: number;                   // HTTP status code
}

// ─── UI HELPERS ──────────────────────────────────────────────────────────────

/** Attributes that block product from reaching 'ready' without human review */
export const HIGH_CRITICALITY_ATTRIBUTES: AttributeName[] = [
  AttributeName.PRESSURE,
  AttributeName.MATERIAL,
  AttributeName.TEMPERATURE_RANGE,
];

/** Human-readable labels for display */
export const ATTRIBUTE_LABELS: Record<AttributeName, string> = {
  [AttributeName.CATEGORY]:          "Category",
  [AttributeName.MATERIAL]:          "Body Material",
  [AttributeName.PRESSURE]:          "Pressure Rating",
  [AttributeName.CONNECTION]:        "End Connection",
  [AttributeName.TEMPERATURE_RANGE]: "Temperature Range",
  [AttributeName.DESCRIPTION]:       "Description",
};

export const SOURCE_TYPE_LABELS: Record<SourceType, string> = {
  [SourceType.MANUFACTURER_DATASHEET]: "Manufacturer Datasheet",
  [SourceType.OFFICIAL_PRODUCT_PAGE]:  "Official Product Page",
  [SourceType.AUTHORIZED_DISTRIBUTOR]: "Authorized Distributor",
  [SourceType.DISTRIBUTOR_PAGE]:       "Distributor Page",
  [SourceType.MARKETPLACE_LISTING]:    "Marketplace Listing",
};

export const PIPELINE_STEP_LABELS: Record<PipelineStep, string> = {
  [PipelineStep.DISCOVERING_SOURCES]:      "Discovering Sources",
  [PipelineStep.RETRIEVING_EVIDENCE]:      "Retrieving Evidence",
  [PipelineStep.EXTRACTING_ATTRIBUTES]:    "Extracting Attributes",
  [PipelineStep.VALIDATING_VALUES]:        "Validating Values",
  [PipelineStep.ASSIGNING_CONFIDENCE]:     "Assigning Confidence",
  [PipelineStep.PREPARING_PRODUCT_RECORD]: "Preparing Product Record",
};
