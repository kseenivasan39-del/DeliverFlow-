/**
 * handlers.ts
 * DeliverFlow — MSW request handlers for mock mode.
 *
 * Active when NEXT_PUBLIC_API_MODE=mock.
 * Serves the three fallback fixtures directly so the UI works
 * without a running backend.
 *
 * Setup in your app:
 *   // src/app/msw-provider.tsx (client component)
 *   if (process.env.NEXT_PUBLIC_API_MODE === "mock") {
 *     const { worker } = await import("@/mocks/browser");
 *     await worker.start({ onUnhandledRequest: "bypass" });
 *   }
 */

import { http, HttpResponse, delay } from "msw";

// ─── FIXTURE IMPORTS ──────────────────────────────────────────────────────────
// In production mock mode these are imported as JSON modules.
// Adjust paths if your Next.js config differs.
import fixtureVerified from "../../shared/demo-data/fallback/VAL-316-100.json";
import fixtureConflict from "../../shared/demo-data/fallback/VAL-316-100-C.json";
import fixtureMissing  from "../../shared/demo-data/fallback/VAL-316-100-M.json";

// ─── CONSTANTS ────────────────────────────────────────────────────────────────

const BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

/** Simulated pipeline delay per step (ms) — makes the demo feel real */
const STEP_DELAY_MS = 800;

// ─── FIXTURE REGISTRY ─────────────────────────────────────────────────────────

const FIXTURE_BY_ID: Record<string, typeof fixtureVerified> = {
  "prod-val-316-100":   fixtureVerified,
  "prod-val-316-100-c": fixtureConflict as typeof fixtureVerified,
  "prod-val-316-100-m": fixtureMissing  as typeof fixtureVerified,
};

const FIXTURE_BY_MPN: Record<string, typeof fixtureVerified> = {
  "VAL-316-100":   fixtureVerified,
  "VAL-316-100-C": fixtureConflict as typeof fixtureVerified,
  "VAL-316-100-M": fixtureMissing  as typeof fixtureVerified,
};

/** In-memory store for created products during a session */
const sessionProducts: Map<string, typeof fixtureVerified> = new Map(
  Object.entries(FIXTURE_BY_ID)
);

/** Tracks which products are mid-pipeline (for polling simulation) */
const pipelineRunning: Set<string> = new Set();

// ─── HELPERS ─────────────────────────────────────────────────────────────────

function notFound(id: string) {
  return HttpResponse.json(
    { error: "product_not_found", message: `No product found with id ${id}`, status: 404 },
    { status: 404 }
  );
}

function conflict(message: string) {
  return HttpResponse.json(
    { error: "conflict", message, status: 409 },
    { status: 409 }
  );
}

function getProduct(id: string) {
  return sessionProducts.get(id) ?? null;
}

// ─── HANDLERS ─────────────────────────────────────────────────────────────────

export const handlers = [

  // POST /products — create product record
  http.post(`${BASE}/products`, async ({ request }) => {
    await delay(300);
    const body = await request.json() as { mpn: string; brand: string; description: string };

    // Check for MPN collision in session
    const existing = FIXTURE_BY_MPN[body.mpn];
    if (existing) {
      return conflict(`MPN ${body.mpn} already exists. Use existing product or enrich it.`);
    }

    // For unknown MPNs create a pending stub using the verified fixture as template
    const newProduct = {
      ...fixtureVerified,
      product_id:        `prod-${body.mpn.toLowerCase().replace(/[^a-z0-9]/g, "-")}`,
      mpn:               body.mpn,
      brand:             body.brand,
      input_description: body.description,
      status:            "pending",
      overall_confidence: null,
      validation_status: "pending",
      warnings:          [],
    };

    sessionProducts.set(newProduct.product_id, newProduct as typeof fixtureVerified);

    return HttpResponse.json(newProduct, { status: 201 });
  }),

  // GET /products/:id — get product
  http.get(`${BASE}/products/:id`, async ({ params }) => {
    await delay(200);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    // If pipeline was running, return a "running" snapshot first
    // then subsequent calls return the final fixture
    if (pipelineRunning.has(id)) {
      const runningProduct = {
        ...product,
        status: "running",
        overall_confidence: null,
        pipeline: {
          ...product.pipeline,
          completed_at: null,
          steps: product.pipeline.steps.map((s, i) => ({
            ...s,
            status: i === 0 ? "completed" : i === 1 ? "running" : "pending",
          })),
        },
      };
      return HttpResponse.json(runningProduct);
    }

    return HttpResponse.json(product);
  }),

  // POST /products/:id/enrich — trigger enrichment
  http.post(`${BASE}/products/:id/enrich`, async ({ params, request }) => {
    await delay(STEP_DELAY_MS);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    const body = await request.json() as { force?: boolean } | null;

    // Mark pipeline as running for the next GET poll
    pipelineRunning.add(id);

    // Simulate async pipeline completion after a short delay
    setTimeout(() => {
      pipelineRunning.delete(id);
      // Restore final fixture state
      const fixture = FIXTURE_BY_ID[id];
      if (fixture) sessionProducts.set(id, fixture);
    }, STEP_DELAY_MS * 5);

    const result = {
      product_id:       id,
      pipeline_status:  "running",
      current_step:     "discovering_sources",
      started_at:       new Date().toISOString(),
      estimated_seconds: 12,
    };

    return HttpResponse.json(result, { status: 202 });
  }),

  // GET /products/:id/evidence — list evidence
  http.get(`${BASE}/products/:id/evidence`, async ({ params, request }) => {
    await delay(250);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    const url = new URL(request.url);
    const sourceTypeFilter = url.searchParams.get("source_type");

    // Build mock evidence from sources on the fixture
    const evidence = product.sources.map((source) => ({
      id:              source.evidence_id ?? `ev-${source.source_id}`,
      product_id:      id,
      source: {
        id:              source.source_id ?? source.id,
        url:             source.url,
        source_type:     source.source_type,
        domain:          source.url ? new URL(source.url).hostname : null,
        title:           source.label,
        authority_score: source.authority_score,
        trust_label:     source.trust_label,
        discovered_at:   product.pipeline.triggered_at,
      },
      raw_text:        `[Mock evidence text for ${source.label}. In live mode this contains the actual extracted page text used for AI attribute extraction.]`,
      retrieved_at:    product.pipeline.triggered_at,
      extraction_error: null,
    }));

    const filtered = sourceTypeFilter
      ? evidence.filter((ev) => ev.source.source_type === sourceTypeFilter)
      : evidence;

    return HttpResponse.json({
      product_id: id,
      evidence:   filtered,
      total:      filtered.length,
    });
  }),

  // POST /products/:id/review — submit review actions
  http.post(`${BASE}/products/:id/review`, async ({ params, request }) => {
    await delay(400);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    const body = await request.json() as { actions: Array<{ attribute_name: string; action: string; edited_value?: string; reviewer_note?: string }> };

    // Apply review actions to the in-memory product copy
    const updated = structuredClone(product) as typeof fixtureVerified & {
      attributes: Record<string, { status: string; value: string | null; conflict_summary?: string | null }>;
    };

    let pendingReviewCount = 0;

    for (const action of body.actions) {
      const attr = updated.attributes[action.attribute_name];
      if (!attr) continue;

      switch (action.action) {
        case "accept":
          attr.status = "accepted";
          break;
        case "edit":
          attr.status = "edited";
          attr.value  = action.edited_value ?? attr.value;
          break;
        case "reject":
          attr.status = "rejected";
          attr.value  = null;
          break;
        default:
          attr.status = "unknown";
          attr.value  = null;
      }
    }

    // Recount needs_review attributes
    pendingReviewCount = Object.values(updated.attributes).filter(
      (a) => a.status === "needs_review" || a.status === "conflict"
    ).length;

    // If all flagged attributes have been reviewed, promote to ready
    if (pendingReviewCount === 0) {
      (updated as unknown as { status: string }).status = "ready";
      updated.warnings = [];
    }

    sessionProducts.set(id, updated as typeof fixtureVerified);

    return HttpResponse.json(updated);
  }),

  // GET /products/:id/export/json — JSON export
  http.get(`${BASE}/products/:id/export/json`, async ({ params }) => {
    await delay(200);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    if (product.status !== "ready" && product.status !== "completed") {
      return HttpResponse.json(
        { error: "pipeline_incomplete", message: "Export is only available when pipeline_status is completed or ready.", status: 409 },
        { status: 409 }
      );
    }

    const exportPayload = {
      mpn:             product.mpn,
      brand:           product.brand,
      pipeline_status: product.status,
      attributes:      Object.fromEntries(
        Object.entries(product.attributes).map(([name, attr]) => {
          const a = attr as { value: string | null; status: string; confidence: number | null; winning_source_id?: string | null };
          return [
            name,
            {
              value:            a.value,
              status:           a.status,
              confidence_score: a.confidence,
              source_url:       a.winning_source_id
                ? product.sources.find((s) => s.source_id === a.winning_source_id)?.url ?? null
                : null,
            },
          ];
        })
      ),
      exported_at: new Date().toISOString(),
    };

    return HttpResponse.json(exportPayload, {
      headers: {
        "Content-Disposition": `attachment; filename="${product.mpn}.json"`,
      },
    });
  }),

  // GET /products/:id/export/csv — CSV export
  http.get(`${BASE}/products/:id/export/csv`, async ({ params }) => {
    await delay(200);
    const id = params.id as string;
    const product = getProduct(id);
    if (!product) return notFound(id);

    const header = "mpn,brand,attribute_name,value,status,confidence_score,source_url";
    const rows = Object.entries(product.attributes).map(([name, attr]) => {
      const a = attr as { value: string | null; status: string; confidence: number | null; winning_source_id?: string | null };
      const sourceUrl = a.winning_source_id
        ? product.sources.find((s) => s.source_id === a.winning_source_id)?.url ?? ""
        : "";
      const value = (a.value ?? "").replace(/,/g, ";").replace(/\n/g, " ");
      return `${product.mpn},${product.brand},${name},${value},${a.status},${a.confidence ?? ""},${sourceUrl}`;
    });

    const csv = [header, ...rows].join("\n");

    return new HttpResponse(csv, {
      status: 200,
      headers: {
        "Content-Type":        "text/csv",
        "Content-Disposition": `attachment; filename="${product.mpn}.csv"`,
      },
    });
  }),

];
