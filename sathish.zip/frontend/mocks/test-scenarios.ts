/**
 * test-scenarios.ts
 * DeliverFlow — frontend test scenario definitions.
 *
 * Used by:
 *   - MSW handlers to serve scenario-specific responses
 *   - Playwright / Vitest browser tests to drive the UI
 *   - Manual QA checklist to verify demo flows
 *
 * Each scenario maps to a fixture in shared/demo-data/fallback/
 * and defines the UI assertions that must pass.
 */

import type { Product, AttributeStatus, PipelineStatus } from "@/lib/types";
import { AttributeName, PipelineStatus as PS, AttributeStatus as AS } from "@/lib/types";

// ─── SCENARIO TYPE ────────────────────────────────────────────────────────────

export interface AttributeAssertion {
  status:             AttributeStatus;
  valueNotNull?:      boolean;
  valueIsNull?:       boolean;
  valueContains?:     string;
  confidenceMin?:     number;
  confidenceIsNull?:  boolean;
  hasConflict?:       boolean;
  candidatesMin?:     number;
  candidatesCount?:   number;
}

export interface ScenarioAssertion {
  pipelineStatus:          PipelineStatus | "ready";
  overallConfidenceMin?:   number;
  overallConfidenceMax?:   number;
  warningsCount?:          number;
  warningsCountMin?:       number;
  hasWarningCode?:         string;
  attributes:              Partial<Record<AttributeName, AttributeAssertion>>;
}

export interface TestScenario {
  id:          string;
  label:       string;
  mpn:         string;
  productId:   string;
  description: string;
  assertions:  ScenarioAssertion;
  /** UI interaction steps for manual QA / Playwright */
  steps:       string[];
}

// ─── SCENARIO DEFINITIONS ─────────────────────────────────────────────────────

export const scenarios: TestScenario[] = [

  // ── GT-001: CLEAN VERIFIED PRODUCT ────────────────────────────────────────
  {
    id:          "TS-001",
    label:       "Clean Verified Product",
    mpn:         "VAL-316-100",
    productId:   "prod-val-316-100",
    description: "All six attributes verified, confidence ≥ 90, no warnings, export enabled.",
    assertions: {
      pipelineStatus:        "ready",
      overallConfidenceMin:  90,
      warningsCount:         0,
      attributes: {
        [AttributeName.CATEGORY]: {
          status:        AS.VERIFIED,
          valueContains: "Ball Valve",
          confidenceMin: 90,
          candidatesMin: 2,
        },
        [AttributeName.MATERIAL]: {
          status:        AS.VERIFIED,
          valueContains: "316",
          confidenceMin: 90,
        },
        [AttributeName.PRESSURE]: {
          status:        AS.VERIFIED,
          valueNotNull:  true,
          valueContains: "bar",
          hasConflict:   false,
          confidenceMin: 90,
          candidatesMin: 2,
        },
        [AttributeName.CONNECTION]: {
          status:        AS.VERIFIED,
          valueNotNull:  true,
          confidenceMin: 85,
        },
        [AttributeName.TEMPERATURE_RANGE]: {
          status:        AS.VERIFIED,
          valueNotNull:  true,
          confidenceMin: 88,
        },
        [AttributeName.DESCRIPTION]: {
          status:       AS.VERIFIED,
          valueNotNull: true,
        },
      },
    },
    steps: [
      "Enter MPN 'VAL-316-100', Brand 'Acme Industrial', Description 'Ball valve'",
      "Click 'Enrich' — pipeline progress bar should animate through all 6 steps",
      "Verify product card shows status badge: 'Ready' (green)",
      "Verify overall confidence badge shows ≥ 90 (e.g. 96)",
      "Verify all 6 attribute rows show 'Verified' status badge (green checkmark)",
      "Verify pressure attribute shows ≥ 2 source agreement indicators",
      "Verify no warning banner is shown",
      "Click 'Export JSON' — download should trigger immediately",
      "Click 'Export CSV' — download should trigger immediately",
      "Open Evidence Viewer — 3 evidence tabs should be visible (Datasheet, Product Page, Distributor)",
    ],
  },

  // ── GT-002: CONFLICT PRODUCT ───────────────────────────────────────────────
  {
    id:          "TS-002",
    label:       "Conflict Product — Pressure Dispute",
    mpn:         "VAL-316-100-C",
    productId:   "prod-val-316-100-c",
    description: "Pressure conflict (10 bar vs 16 bar). Confidence capped at 70. Review required.",
    assertions: {
      pipelineStatus:       PS.NEEDS_REVIEW,
      overallConfidenceMax: 70,
      warningsCountMin:     1,
      hasWarningCode:       "ATTRIBUTE_CONFLICT",
      attributes: {
        [AttributeName.PRESSURE]: {
          status:         AS.CONFLICT,
          hasConflict:    true,
          candidatesMin:  2,
          valueNotNull:   true,
        },
        [AttributeName.CATEGORY]: {
          status:       AS.VERIFIED,
          valueNotNull: true,
        },
        [AttributeName.MATERIAL]: {
          status:       AS.VERIFIED,
          valueContains: "316",
        },
        [AttributeName.CONNECTION]: {
          status:       AS.VERIFIED,
          valueNotNull: true,
        },
        [AttributeName.TEMPERATURE_RANGE]: {
          status:       AS.VERIFIED,
          valueNotNull: true,
        },
      },
    },
    steps: [
      "Enter MPN 'VAL-316-100-C', Brand 'Acme Industrial', Description 'Class 150 flanged ball valve'",
      "Click 'Enrich'",
      "Verify status badge shows 'Needs Review' (amber/orange)",
      "Verify overall confidence badge shows ≤ 70",
      "Verify warning banner: 'Pressure conflict detected between manufacturer datasheet (10 bar) and distributor page (16 bar)'",
      "Verify pressure attribute row shows 'Conflict' badge (red) with conflict icon",
      "Click on the pressure conflict row to expand the Conflict Panel",
      "Verify Conflict Panel shows: Source A (Manufacturer Datasheet, authority 1.0) → 10 bar",
      "Verify Conflict Panel shows: Source B (ProLine Industrial, authority 0.58) → 16 bar",
      "Verify Conflict Panel shows conflict_summary text mentioning 'Class 150' and 'PN16'",
      "Click 'Accept' on the 10 bar value (correct value from manufacturer)",
      "Verify pressure attribute row changes to 'Accepted' badge",
      "Verify product status badge transitions to 'Ready'",
      "Verify Export buttons become enabled",
    ],
  },

  // ── GT-003: MISSING EVIDENCE PRODUCT ──────────────────────────────────────
  {
    id:          "TS-003",
    label:       "Missing Evidence Product — No Hallucination",
    mpn:         "VAL-316-100-M",
    productId:   "prod-val-316-100-m",
    description: "Temperature redacted in source. Must show null value — never invent a temperature.",
    assertions: {
      pipelineStatus:       PS.NEEDS_REVIEW,
      overallConfidenceMax: 65,
      hasWarningCode:       "ATTRIBUTE_MISSING",
      attributes: {
        [AttributeName.TEMPERATURE_RANGE]: {
          status:          AS.MISSING,
          valueIsNull:     true,
          confidenceIsNull: true,
          candidatesCount: 0,
        },
        [AttributeName.DESCRIPTION]: {
          status:      AS.MISSING,
          valueIsNull: true,
        },
        [AttributeName.CONNECTION]: {
          status:        AS.VERIFIED,
          valueContains: "NPT",
          valueNotNull:  true,
        },
        [AttributeName.PRESSURE]: {
          status:       AS.LOW_CONFIDENCE,
          valueNotNull: true,
        },
      },
    },
    steps: [
      "Enter MPN 'VAL-316-100-M', Brand 'Acme Industrial', Description 'Cryogenic service ball valve'",
      "Click 'Enrich'",
      "Verify status badge: 'Needs Review' (amber)",
      "Verify confidence badge shows ≤ 65",
      "Verify temperature_range row shows 'Missing' badge (grey) — NOT a value",
      "Verify temperature_range row shows reason: 'Redacted in source document'",
      "Verify temperature_range value cell shows '—' or null, NEVER a number",
      "Verify description row shows 'Missing' badge with reason: 'Insufficient verified attributes'",
      "Verify pipeline warning: 'ATTRIBUTE_MISSING on temperature_range — High severity'",
      "Open Evidence Viewer → Manufacturer Datasheet tab",
      "Verify raw evidence text shows '[REDACTED — PENDING CRYOGENIC CERT UPDATE]' in temperature section",
      "Click 'Edit' on temperature_range — type '-196°C to +200°C' as corrected value",
      "Click 'Save' — verify temperature_range status changes to 'Edited'",
    ],
  },

];

// ─── ASSERTION RUNNER ─────────────────────────────────────────────────────────
/**
 * Programmatic assertion runner for use with Vitest.
 * Import in test files to avoid duplicating assertion logic.
 *
 * Usage:
 *   import { assertScenario } from "@/mocks/test-scenarios";
 *   it("clean product is ready", () => {
 *     assertScenario(product, scenarios[0]);
 *   });
 */

export function assertScenario(
  product: Product,
  scenario: TestScenario,
  expect: (value: unknown) => { toBe: (v: unknown) => void; toBeNull: () => void; toBeGreaterThanOrEqual: (v: number) => void; toBeLessThanOrEqual: (v: number) => void; toContain: (v: string) => void; toBeGreaterThan: (v: number) => void; },
): void {
  const { assertions } = scenario;

  // Pipeline status
  expect(product.status).toBe(assertions.pipelineStatus);

  // Confidence
  if (assertions.overallConfidenceMin !== undefined) {
    expect(product.overall_confidence).toBeGreaterThanOrEqual(assertions.overallConfidenceMin);
  }
  if (assertions.overallConfidenceMax !== undefined && product.overall_confidence !== null) {
    expect(product.overall_confidence).toBeLessThanOrEqual(assertions.overallConfidenceMax);
  }

  // Warnings
  if (assertions.warningsCount !== undefined) {
    expect(product.warnings.length).toBe(assertions.warningsCount);
  }
  if (assertions.warningsCountMin !== undefined) {
    expect(product.warnings.length).toBeGreaterThanOrEqual(assertions.warningsCountMin);
  }
  if (assertions.hasWarningCode) {
    const codes = product.warnings.map((w) => w.code);
    expect(codes.includes(assertions.hasWarningCode)).toBe(true);
  }

  // Attributes
  for (const [attrName, attrAssert] of Object.entries(assertions.attributes)) {
    const attr = product.attributes[attrName as AttributeName];

    expect(attr.status).toBe(attrAssert.status);

    if (attrAssert.valueNotNull) {
      expect(attr.value !== null && attr.value !== undefined).toBe(true);
    }
    if (attrAssert.valueIsNull) {
      expect(attr.value).toBeNull();
    }
    if (attrAssert.valueContains && attr.value) {
      expect(attr.value).toContain(attrAssert.valueContains);
    }
    if (attrAssert.confidenceMin !== undefined && attr.confidence !== null) {
      expect(attr.confidence).toBeGreaterThanOrEqual(attrAssert.confidenceMin);
    }
    if (attrAssert.confidenceIsNull) {
      expect(attr.confidence).toBeNull();
    }
    if (attrAssert.candidatesMin !== undefined) {
      expect(attr.candidates.length).toBeGreaterThanOrEqual(attrAssert.candidatesMin);
    }
    if (attrAssert.candidatesCount !== undefined) {
      expect(attr.candidates.length).toBe(attrAssert.candidatesCount);
    }
  }
}

// ─── LOOKUP HELPERS ───────────────────────────────────────────────────────────

export function getScenarioByMpn(mpn: string): TestScenario | undefined {
  return scenarios.find((s) => s.mpn === mpn);
}

export function getScenarioById(id: string): TestScenario | undefined {
  return scenarios.find((s) => s.id === id);
}
