"""
main.py — DeliverFlow FastAPI application entry point.

Start with:
    uvicorn main:app --reload --port 8000

Swagger UI: http://localhost:8000/docs
OpenAPI JSON: http://localhost:8000/openapi.json
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(
    title="DeliverFlow API",
    version="1.0.0",
    description=(
        "AI-powered product intelligence pipeline for industrial commerce. "
        "Demo category: Industrial Valves."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000"],  # Next.js dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Import and register routers (implement these next)
# from routers import products, enrich, evidence, review, export
# app.include_router(products.router, prefix="/products", tags=["Products"])
# app.include_router(enrich.router,   prefix="/products", tags=["Enrichment"])
# app.include_router(evidence.router, prefix="/products", tags=["Evidence"])
# app.include_router(review.router,   prefix="/products", tags=["Review"])
# app.include_router(export.router,   prefix="/products", tags=["Export"])


@app.get("/", include_in_schema=False)
def health_check():
    return {"status": "ok", "service": "deliverflow-api", "version": "1.0.0"}
