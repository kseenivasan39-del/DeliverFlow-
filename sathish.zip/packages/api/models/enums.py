"""
enums.py — Canonical enumerations for DeliverFlow.

This file is the single source of truth for all enum values used
throughout the backend. Keep in sync with contracts/openapi.yaml.
"""

from enum import Enum


class PipelineStep(str, Enum):
    DISCOVERING_SOURCES = "discovering_sources"
    RETRIEVING_EVIDENCE = "retrieving_evidence"
    EXTRACTING_ATTRIBUTES = "extracting_attributes"
    VALIDATING_VALUES = "validating_values"
    ASSIGNING_CONFIDENCE = "assigning_confidence"
    PREPARING_PRODUCT_RECORD = "preparing_product_record"


class PipelineStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    NEEDS_REVIEW = "needs_review"
    COMPLETED = "completed"
    FAILED = "failed"


class AttributeName(str, Enum):
    CATEGORY = "category"
    MATERIAL = "material"
    PRESSURE = "pressure"
    CONNECTION = "connection"
    TEMPERATURE_RANGE = "temperature_range"
    DESCRIPTION = "description"


class SourceType(str, Enum):
    MANUFACTURER_DATASHEET = "manufacturer_datasheet"
    OFFICIAL_PRODUCT_PAGE = "official_product_page"
    AUTHORIZED_DISTRIBUTOR = "authorized_distributor"
    DISTRIBUTOR_PAGE = "distributor_page"
    MARKETPLACE_LISTING = "marketplace_listing"


class AttributeStatus(str, Enum):
    VERIFIED = "verified"
    LOW_CONFIDENCE = "low_confidence"
    CONFLICT = "conflict"
    MISSING = "missing"
    NEEDS_REVIEW = "needs_review"
    ACCEPTED = "accepted"
    EDITED = "edited"
    REJECTED = "rejected"
    UNKNOWN = "unknown"


class ReviewActionType(str, Enum):
    ACCEPT = "accept"
    EDIT = "edit"
    REJECT = "reject"


# Source reliability weights used in confidence scoring.
# Keep in sync with docs/confidence_model.md.
SOURCE_RELIABILITY: dict[SourceType, float] = {
    SourceType.MANUFACTURER_DATASHEET: 1.00,
    SourceType.OFFICIAL_PRODUCT_PAGE:  0.90,
    SourceType.AUTHORIZED_DISTRIBUTOR: 0.80,
    SourceType.DISTRIBUTOR_PAGE:       0.60,
    SourceType.MARKETPLACE_LISTING:    0.40,
}

# Default confidence threshold below which attributes are flagged needs_review.
DEFAULT_CONFIDENCE_THRESHOLD: float = 0.75
