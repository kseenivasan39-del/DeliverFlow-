"""
product.py — Pydantic/SQLModel schemas for Product and related request/response types.
"""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, Field

from .enums import AttributeName, AttributeStatus, PipelineStatus, PipelineStep, ReviewActionType, SourceType


# ─── Source ───────────────────────────────────────────────────────────────────

class Source(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    url: str
    source_type: SourceType
    domain: Optional[str] = None
    title: Optional[str] = None
    reliability_score: float = Field(ge=0.0, le=1.0)
    discovered_at: datetime = Field(default_factory=datetime.utcnow)


# ─── Evidence ─────────────────────────────────────────────────────────────────

class Evidence(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    product_id: str
    source: Source
    raw_text: str
    retrieved_at: datetime = Field(default_factory=datetime.utcnow)
    extraction_error: Optional[str] = None


# ─── Attribute ────────────────────────────────────────────────────────────────

class CandidateValue(BaseModel):
    value: str
    source_id: str
    source_type: Optional[SourceType] = None
    source_url: Optional[str] = None
    extraction_note: Optional[str] = None
    confidence_score: float = Field(ge=0.0, le=1.0)


class Attribute(BaseModel):
    name: AttributeName
    value: Optional[str] = None
    status: AttributeStatus = AttributeStatus.UNKNOWN
    confidence_score: Optional[float] = Field(default=None, ge=0.0, le=1.0)
    candidates: List[CandidateValue] = Field(default_factory=list)
    conflict_summary: Optional[str] = None
    review_note: Optional[str] = None
    validated_at: Optional[datetime] = None
    reviewed_at: Optional[datetime] = None


# ─── Review ───────────────────────────────────────────────────────────────────

class ReviewAction(BaseModel):
    attribute_name: AttributeName
    action: ReviewActionType
    edited_value: Optional[str] = None
    reviewer_note: Optional[str] = None
    reviewed_by: Optional[str] = "demo-reviewer"


class ReviewRequest(BaseModel):
    actions: List[ReviewAction] = Field(min_length=1)


# ─── Product ──────────────────────────────────────────────────────────────────

class Product(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    mpn: str = Field(min_length=2, max_length=100)
    brand: str = Field(min_length=1, max_length=100)
    description: str = Field(min_length=5, max_length=500)
    pipeline_status: PipelineStatus = PipelineStatus.PENDING
    current_step: Optional[PipelineStep] = None
    attributes: List[Attribute] = Field(default_factory=list)
    source_count: int = 0
    evidence_count: int = 0
    needs_review_count: int = 0
    enriched_at: Optional[datetime] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)


class CreateProductRequest(BaseModel):
    mpn: str = Field(min_length=2, max_length=100)
    brand: str = Field(min_length=1, max_length=100)
    description: str = Field(min_length=5, max_length=500)


# ─── Enrichment ───────────────────────────────────────────────────────────────

class EnrichRequest(BaseModel):
    force: bool = False
    source_types: Optional[List[SourceType]] = None
    confidence_threshold: float = Field(default=0.75, ge=0.0, le=1.0)


class EnrichmentResult(BaseModel):
    product_id: str
    pipeline_status: PipelineStatus
    current_step: PipelineStep
    started_at: datetime = Field(default_factory=datetime.utcnow)
    estimated_seconds: int = 15


# ─── Export ───────────────────────────────────────────────────────────────────

class AttributeExport(BaseModel):
    value: str
    status: AttributeStatus
    confidence_score: Optional[float] = None
    source_url: Optional[str] = None


class ProductExport(BaseModel):
    mpn: str
    brand: str
    pipeline_status: PipelineStatus
    attributes: dict[str, AttributeExport]
    exported_at: datetime = Field(default_factory=datetime.utcnow)


# ─── Error ────────────────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    error: str
    message: str
    details: Optional[dict] = None
