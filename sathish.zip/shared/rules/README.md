# DeliverFlow Rules Engine

This directory contains the deterministic rules that govern the DeliverFlow
enrichment pipeline. All AI extraction output passes through these rules before
a confidence score is assigned or a status is set.

## Files

| File | Purpose |
|---|---|
| `source_authority.yaml` | Trust weight (0–1) per source type. Used in confidence formula. |
| `validation.yaml` | Per-attribute validation, normalization, and conflict detection rules. |
| `confidence.yaml` | Deterministic confidence scoring formula, thresholds, and criticality weights. |
| `status_machine.yaml` | Legal states and transitions for attribute_status and product_status. |

## Design Principles

**1. Rules are the source of truth for status decisions.**
The AI extraction prompt extracts values. The rules engine decides what to do with them.
An AI-extracted value with a high model confidence can still become `conflict` or `missing`
if the rules say so.

**2. No silent resolution.**
The rules engine never quietly picks one conflicting value over another, except in the
narrow case of a ≤5% pressure variance (treated as rounding). All other conflicts are
routed to human review.

**3. Missing ≠ low_confidence.**
If no evidence exists for an attribute, the status is `missing` — not `low_confidence`.
`low_confidence` means evidence exists but is weak. These are different problems
requiring different review behaviors.

**4. Deterministic by design.**
Given the same evidence and sources, the rules engine always produces the same output.
There are no random elements, no model-dependent thresholds. This makes the demo
reproducible and the behavior explainable to judges.

## Evaluation Order

For each extracted attribute candidate:

```
1. Type check          → is the value the right data type?
2. Null check          → is the value null or empty?
3. Pattern / enum      → does the value match known formats?
4. Plausibility        → is the numeric value in a sensible range?
5. Conflict detection  → do multiple candidates disagree?
6. Normalization       → convert to canonical form (applied only if valid)
7. Confidence scoring  → compute integer score [0, 99]
8. Status assignment   → verified / low_confidence / conflict / missing
9. Product rollup      → weighted average → product_status
```

## Attribute Criticality

| Attribute | Criticality | Reason |
|---|---|---|
| `pressure` | high | Safety-relevant. Wrong value = wrong product selection for pressure systems. |
| `material` | high | Safety-relevant. Material compatibility is critical in process engineering. |
| `temperature_range` | high | Safety-relevant. Determines seat and seal viability. |
| `connection` | medium | Fitment-critical but less likely to cause safety issues if wrong. |
| `category` | medium | Important for classification; not directly safety-relevant. |
| `description` | low | Synthesized field. Quality issue, not safety issue, if wrong. |

## Confidence Score Formula

```
confidence = clamp(round(
  model_confidence          # 0–70  (extraction clarity tier)
  + source_authority_bonus  # 0–20  (authority_score × 20)
  + evidence_quality_bonus  # up to +15 (signals: direct spec, MPN match, grade, etc.)
  + agreement_bonus         # up to +6  (+3 per agreeing source, max 2)
  - conflict_penalty        # -25 if conflict detected
  - ambiguity_penalty       # -10 to -15 for generic or family-level evidence
), 0, 99)
```

## Status Thresholds

| Score | Status |
|---|---|
| 85 – 99 | `verified` |
| 60 – 84 | `needs_review` |
| 0 – 59 | `low_confidence` |
| — | `conflict` (override — set by rule, not score) |
| — | `missing` (override — set by rule when all candidates null) |

## Product Status Caps

| Condition | Confidence Cap | Product Status |
|---|---|---|
| Any high-criticality attribute is `conflict` | 70 | `needs_review` |
| Any high-criticality attribute is `missing` | 65 | `needs_review` |
| All attributes verified, score ≥ 85 | none | `ready` |

## Keeping Rules in Sync

- `source_authority.yaml` is referenced by `confidence.yaml` (authority_bonus) and
  by `conflict_detection` in `validation.yaml` (which source to prefer in minor variance).
- `validation.yaml` sets attribute status; `status_machine.yaml` governs legal transitions.
- `confidence.yaml` thresholds must agree with `status_machine.yaml` transition conditions.

If you change a threshold in one file, search for it in the others.

## Implementation Notes for Backend

```python
# Recommended service call order in pipeline.py:

from rules import source_authority, validation, confidence, status_machine

# 1. Load rules at startup (cached, not re-read per request)
rules = RulesEngine.load("shared/rules/")

# 2. After extraction
for candidate in candidates:
    candidate.is_valid = rules.validation.validate(candidate)
    candidate.normalized_value = rules.validation.normalize(candidate)

# 3. After all candidates validated
for attribute in attributes:
    conflict = rules.validation.detect_conflict(attribute.candidates)
    attribute.confidence = rules.confidence.score(attribute, conflict)
    attribute.status = rules.confidence.status(attribute.confidence, conflict)

# 4. Product rollup
product.confidence = rules.confidence.product_score(attributes)
product.status = rules.status_machine.resolve_product_status(attributes, product.confidence)
```
